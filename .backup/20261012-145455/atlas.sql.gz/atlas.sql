--
-- PostgreSQL database dump
--

\restrict pDGeAw2IHj4DZeSO6WGWOPpVqKoSGSSrj5pP0N5Yt6A9werxji2yGByT8r08NCh

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_user; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.app_user (
    id integer NOT NULL,
    username text NOT NULL,
    email text,
    full_name text,
    role text DEFAULT 'admin'::text NOT NULL,
    password_hash text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_login_at timestamp with time zone
);


ALTER TABLE public.app_user OWNER TO atlas;

--
-- Name: app_user_id_seq; Type: SEQUENCE; Schema: public; Owner: atlas
--

CREATE SEQUENCE public.app_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.app_user_id_seq OWNER TO atlas;

--
-- Name: app_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atlas
--

ALTER SEQUENCE public.app_user_id_seq OWNED BY public.app_user.id;


--
-- Name: asset; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.asset (
    asset_id text NOT NULL,
    asset_name text NOT NULL,
    asset_type text,
    asset_category text,
    ip_address inet,
    ip_or_type_raw text,
    cluster text,
    datacenter text,
    current_location text,
    site_id integer,
    room_id integer,
    rack_id integer,
    parent_asset_id text,
    attachment_label text,
    capacity text,
    replacement_target text,
    usage_status text,
    usage_status_label text,
    usage_start_date date,
    handover_date date,
    handover_status text,
    purchase_invoice text,
    purchase_price_vnd numeric(18,0),
    supplier_code text,
    supplier_name text,
    warranty_months integer,
    warranty_end_date date,
    description text,
    source_sheet text,
    source_row integer,
    review_flags text[] DEFAULT '{}'::text[] NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    origin text DEFAULT 'import'::text NOT NULL,
    rack_unit integer,
    in_store boolean DEFAULT false NOT NULL,
    code_pending boolean DEFAULT false NOT NULL,
    serial text
);


ALTER TABLE public.asset OWNER TO atlas;

--
-- Name: asset_code_seq; Type: SEQUENCE; Schema: public; Owner: atlas
--

CREATE SEQUENCE public.asset_code_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.asset_code_seq OWNER TO atlas;

--
-- Name: asset_event; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.asset_event (
    id bigint NOT NULL,
    asset_id text NOT NULL,
    event_sequence integer NOT NULL,
    event_type text,
    event_date date,
    location text,
    usage_object text,
    notes text,
    declared_transition_count integer,
    source_column text,
    source_row integer,
    review_flags text[] DEFAULT '{}'::text[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    origin text DEFAULT 'import'::text NOT NULL
);


ALTER TABLE public.asset_event OWNER TO atlas;

--
-- Name: asset_event_id_seq; Type: SEQUENCE; Schema: public; Owner: atlas
--

CREATE SEQUENCE public.asset_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.asset_event_id_seq OWNER TO atlas;

--
-- Name: asset_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atlas
--

ALTER SEQUENCE public.asset_event_id_seq OWNED BY public.asset_event.id;


--
-- Name: asset_type; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.asset_type (
    code text NOT NULL,
    label text NOT NULL,
    note text,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.asset_type OWNER TO atlas;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL,
    username text,
    action text NOT NULL,
    entity text NOT NULL,
    entity_id text,
    changes jsonb,
    note text
);


ALTER TABLE public.audit_log OWNER TO atlas;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: atlas
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO atlas;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atlas
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: backup_config; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.backup_config (
    id smallint DEFAULT 1 NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    hour smallint DEFAULT 2 NOT NULL,
    minute smallint DEFAULT 0 NOT NULL,
    keep smallint DEFAULT 14 NOT NULL,
    last_run_at timestamp with time zone,
    last_status text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT backup_config_hour_check CHECK (((hour >= 0) AND (hour <= 23))),
    CONSTRAINT backup_config_id_check CHECK ((id = 1)),
    CONSTRAINT backup_config_keep_check CHECK (((keep >= 1) AND (keep <= 365))),
    CONSTRAINT backup_config_minute_check CHECK (((minute >= 0) AND (minute <= 59)))
);


ALTER TABLE public.backup_config OWNER TO atlas;

--
-- Name: cluster; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.cluster (
    name text NOT NULL,
    note text
);


ALTER TABLE public.cluster OWNER TO atlas;

--
-- Name: export_template; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.export_template (
    id integer NOT NULL,
    name text NOT NULL,
    note text,
    file_name text,
    sheet_name text DEFAULT 'Sheet1'::text NOT NULL,
    header_rows integer DEFAULT 1 NOT NULL,
    scope jsonb DEFAULT '{}'::jsonb NOT NULL,
    maps jsonb DEFAULT '{}'::jsonb NOT NULL,
    col_defs jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.export_template OWNER TO atlas;

--
-- Name: export_template_id_seq; Type: SEQUENCE; Schema: public; Owner: atlas
--

CREATE SEQUENCE public.export_template_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.export_template_id_seq OWNER TO atlas;

--
-- Name: export_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atlas
--

ALTER SEQUENCE public.export_template_id_seq OWNED BY public.export_template.id;


--
-- Name: import_log; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.import_log (
    id bigint NOT NULL,
    kind text NOT NULL,
    file_name text NOT NULL,
    file_type text NOT NULL,
    rows_read integer DEFAULT 0 NOT NULL,
    added integer DEFAULT 0 NOT NULL,
    updated integer DEFAULT 0 NOT NULL,
    skipped integer DEFAULT 0 NOT NULL,
    username text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.import_log OWNER TO atlas;

--
-- Name: import_log_id_seq; Type: SEQUENCE; Schema: public; Owner: atlas
--

CREATE SEQUENCE public.import_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.import_log_id_seq OWNER TO atlas;

--
-- Name: import_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atlas
--

ALTER SEQUENCE public.import_log_id_seq OWNED BY public.import_log.id;


--
-- Name: placement; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.placement (
    id bigint NOT NULL,
    asset_id text NOT NULL,
    rack_id integer NOT NULL,
    start_u integer NOT NULL,
    size_u integer DEFAULT 1 NOT NULL,
    from_date date,
    to_date date,
    CONSTRAINT placement_check CHECK (((start_u > 0) AND (size_u > 0)))
);


ALTER TABLE public.placement OWNER TO atlas;

--
-- Name: placement_id_seq; Type: SEQUENCE; Schema: public; Owner: atlas
--

CREATE SEQUENCE public.placement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.placement_id_seq OWNER TO atlas;

--
-- Name: placement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atlas
--

ALTER SEQUENCE public.placement_id_seq OWNED BY public.placement.id;


--
-- Name: rack; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.rack (
    id integer NOT NULL,
    room_id integer NOT NULL,
    code text NOT NULL,
    height_u integer DEFAULT 42 NOT NULL,
    status text DEFAULT 'Đang sử dụng'::text NOT NULL
);


ALTER TABLE public.rack OWNER TO atlas;

--
-- Name: rack_id_seq; Type: SEQUENCE; Schema: public; Owner: atlas
--

CREATE SEQUENCE public.rack_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rack_id_seq OWNER TO atlas;

--
-- Name: rack_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atlas
--

ALTER SEQUENCE public.rack_id_seq OWNED BY public.rack.id;


--
-- Name: room; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.room (
    id integer NOT NULL,
    site_id integer NOT NULL,
    code text NOT NULL,
    name text
);


ALTER TABLE public.room OWNER TO atlas;

--
-- Name: room_id_seq; Type: SEQUENCE; Schema: public; Owner: atlas
--

CREATE SEQUENCE public.room_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.room_id_seq OWNER TO atlas;

--
-- Name: room_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atlas
--

ALTER SEQUENCE public.room_id_seq OWNED BY public.room.id;


--
-- Name: site; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.site (
    id integer NOT NULL,
    name text NOT NULL,
    kind text DEFAULT 'datacenter'::text NOT NULL,
    status text DEFAULT 'Đang sử dụng'::text NOT NULL
);


ALTER TABLE public.site OWNER TO atlas;

--
-- Name: site_id_seq; Type: SEQUENCE; Schema: public; Owner: atlas
--

CREATE SEQUENCE public.site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.site_id_seq OWNER TO atlas;

--
-- Name: site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: atlas
--

ALTER SEQUENCE public.site_id_seq OWNED BY public.site.id;


--
-- Name: status_catalog; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.status_catalog (
    code text NOT NULL,
    label text NOT NULL,
    tag_style text DEFAULT 'idle'::text NOT NULL,
    attention boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.status_catalog OWNER TO atlas;

--
-- Name: supplier; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.supplier (
    code text NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.supplier OWNER TO atlas;

--
-- Name: user_session; Type: TABLE; Schema: public; Owner: atlas
--

CREATE TABLE public.user_session (
    token text NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.user_session OWNER TO atlas;

--
-- Name: app_user id; Type: DEFAULT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.app_user ALTER COLUMN id SET DEFAULT nextval('public.app_user_id_seq'::regclass);


--
-- Name: asset_event id; Type: DEFAULT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.asset_event ALTER COLUMN id SET DEFAULT nextval('public.asset_event_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: export_template id; Type: DEFAULT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.export_template ALTER COLUMN id SET DEFAULT nextval('public.export_template_id_seq'::regclass);


--
-- Name: import_log id; Type: DEFAULT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.import_log ALTER COLUMN id SET DEFAULT nextval('public.import_log_id_seq'::regclass);


--
-- Name: placement id; Type: DEFAULT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.placement ALTER COLUMN id SET DEFAULT nextval('public.placement_id_seq'::regclass);


--
-- Name: rack id; Type: DEFAULT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.rack ALTER COLUMN id SET DEFAULT nextval('public.rack_id_seq'::regclass);


--
-- Name: room id; Type: DEFAULT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.room ALTER COLUMN id SET DEFAULT nextval('public.room_id_seq'::regclass);


--
-- Name: site id; Type: DEFAULT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.site ALTER COLUMN id SET DEFAULT nextval('public.site_id_seq'::regclass);


--
-- Data for Name: app_user; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.app_user (id, username, email, full_name, role, password_hash, is_active, created_at, last_login_at) FROM stdin;
2	admin	vydh@matbao.com	Đặng Hùng Vỹ	admin	scrypt$16384$8$1$Amteir3lhU6vVYdc+yM3Og==$e1dL1Q8+vSvngaoAtYdJOp7SN2VgkurFnhH03sHX1EM=	t	2026-09-10 02:35:30.130115+00	2026-10-12 07:05:17.44628+00
\.


--
-- Data for Name: asset; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.asset (asset_id, asset_name, asset_type, asset_category, ip_address, ip_or_type_raw, cluster, datacenter, current_location, site_id, room_id, rack_id, parent_asset_id, attachment_label, capacity, replacement_target, usage_status, usage_status_label, usage_start_date, handover_date, handover_status, purchase_invoice, purchase_price_vnd, supplier_code, supplier_name, warranty_months, warranty_end_date, description, source_sheet, source_row, review_flags, updated_at, created_at, origin, rack_unit, in_store, code_pending, serial) FROM stdin;
svr-p07-u26	Email Node 06 - 128.6	server	\N	103.110.128.6	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	2*Intel(R) Xeon(R) Gold 5318Y CPU @ 2.10GHz (48 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	29	{}	2026-09-15 04:00:16.745015+00	2026-09-15 03:25:35.015644+00	import	26	f	f	A411795X3307867
svr-aq53-u24	Node VNPT104	server	\N	103.138.89.135	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	\N	\N	2*Intel(R) Xeon(R) Gold 5218R CPU @ 2.10GHz (40 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	122	{}	2026-09-15 04:16:42.662728+00	2026-09-15 03:25:35.015644+00	import	24	f	f	ARQGPOO00005
svr-j6-u30	Node Cluster926 - 49.189	server	\N	103.15.49.189	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	107	{}	2026-09-15 04:32:47.26961+00	2026-09-15 03:25:35.015644+00	import	30	f	f	\N
svr-j5-u09	Node Cluster802 - 49.74	server	\N	103.15.49.74	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4114 CPU @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	73	{}	2026-09-15 04:33:04.585401+00	2026-09-15 03:25:35.015644+00	import	9	f	f	\N
svr-bd51-u35	MatBao-CA Node 06	server	\N	192.168.201.6	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	2*Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz (16 Cores) · RAM 128.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	146	{}	2026-09-15 04:40:41.334438+00	2026-09-15 03:25:35.015644+00	import	35	f	f	\N
svr-d12-u31	OPS - COMPUTE	server	\N	10.10.70.12	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz · RAM 251.8 GiB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	odsvps02 · Supermicro Node 2U	netbox_devices (1).csv	12	{}	2026-09-15 07:48:31.189616+00	2026-09-15 03:25:35.015644+00	import	31	f	f	\N
svr-j3-2425	extra backup	server	server	\N	server	ClusterX1	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	2017-10-01	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	111	{rack_from_asset_code,location_from_last_transfer}	2026-09-17 03:40:42.465524+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-j3-2627	backup	server	server	\N	server	ClusterX1	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	2017-10-01	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	112	{rack_from_asset_code,location_from_last_transfer}	2026-09-17 03:40:42.531877+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-j6-1516	backup	network_or_host	component	103.15.49.64	103.15.49.64	backup	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	2017-10-01	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	97	{rack_from_asset_code,location_from_last_transfer}	2026-09-17 03:40:42.60262+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-001	SVR-KHO-001	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	210	{}	2026-09-17 03:40:42.667547+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-002	SVR-KHO-002	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	211	{}	2026-09-17 03:40:42.737783+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-003	SVR-KHO-003	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	212	{}	2026-09-17 03:40:42.821581+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-004	SVR-KHO-004	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	213	{}	2026-09-17 03:40:42.905687+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-005	SVR-KHO-005	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	214	{}	2026-09-17 03:40:42.981799+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-006	SVR-KHO-006	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	215	{}	2026-09-17 03:40:43.051667+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-007	SVR-KHO-007	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	216	{}	2026-09-17 03:40:43.117313+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-008	SVR-KHO-008	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	217	{}	2026-09-17 03:40:43.185403+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-p07-u33	Email Node 03 - 128.3	server	\N	103.110.128.3	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	2*Intel(R) Xeon(R) Gold 5318Y CPU @ 2.10GHz (48 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	15	{}	2026-09-15 04:00:16.958874+00	2026-09-15 03:25:35.015644+00	import	33	f	f	A411795X3307878
CHUA-GAN-0023	Ổ cứng 2.5" 240G SSD hiệu Samsung	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	240G	\N	in_stock	\N	\N	2023-05-04	Đã bàn giao	000000005	1328000	MB007275	Công Ty TNHH Kỹ Thuật Hạ Tầng IT	36	2026-05-01	SSD	TỔNG HỢP	34	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0024	Ổ cứng 2.5" 240G SSD hiệu Samsung	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	240G	\N	in_stock	\N	\N	2023-05-04	Đã bàn giao	000000005	1328000	MB007275	Công Ty TNHH Kỹ Thuật Hạ Tầng IT	36	2026-05-01	SSD	TỔNG HỢP	35	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0025	Ổ cứng 2.5" 240G SSD hiệu Samsung	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	240G	\N	in_stock	\N	\N	2023-05-04	Đã bàn giao	000000005	1328000	MB007275	Công Ty TNHH Kỹ Thuật Hạ Tầng IT	36	2026-05-01	SSD	TỔNG HỢP	36	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0026	Ổ cứng 2.5" 240G SSD hiệu Samsung	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	240G	\N	in_stock	\N	\N	2023-05-04	Đã bàn giao	000000005	1328000	MB007275	Công Ty TNHH Kỹ Thuật Hạ Tầng IT	36	2026-05-01	SSD	TỔNG HỢP	37	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0027	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	441	{status_from_last_transfer}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0028	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	442	{status_from_last_transfer}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0029	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	443	{status_from_last_transfer}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0030	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	444	{status_from_last_transfer}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0031	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	445	{status_from_last_transfer}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0032	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	446	{status_from_last_transfer}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0033	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	447	{status_from_last_transfer}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0034	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	448	{status_from_last_transfer}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0035	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	450	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0036	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	451	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0037	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	452	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0038	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	453	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0039	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	454	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0040	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	455	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0041	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	456	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0042	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	457	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0043	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	458	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0044	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	459	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0045	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	460	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0046	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	461	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0047	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	462	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0048	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	degraded	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	463	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0049	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	degraded	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	464	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0050	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	degraded	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	465	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0051	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	degraded	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	466	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0052	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	468	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0053	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	469	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
ssd-8tb-001	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
CHUA-GAN-0054	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	470	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0055	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	471	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0056	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	472	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0057	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	473	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0058	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	474	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0059	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	475	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0060	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	240G	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	476	{status_from_last_transfer}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0061	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	240G	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	477	{status_from_last_transfer}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0062	SSD SS 240G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	240G	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	478	{status_from_last_transfer}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0063	SSD SS 480G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	435	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0064	SSD SS 480G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	436	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
svr-aq54-u23	Node VNPT112	server	\N	103.138.89.143	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	\N	\N	2*Intel(R) Xeon(R) Gold 5118 CPU @ 2.30GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	149	{}	2026-09-15 04:16:42.806438+00	2026-09-15 03:25:35.015644+00	import	23	f	f	\N
svr-j6-u33	Node Cluster930 - 49.46	server	\N	103.15.49.46	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2630 v4 @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	105	{}	2026-09-15 04:32:47.477947+00	2026-09-15 03:25:35.015644+00	import	33	f	f	\N
svr-j5-u06	Node Cluster801 - 49.73	server	\N	103.15.49.73	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4114 CPU @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	36	{}	2026-09-15 04:33:04.657587+00	2026-09-15 03:25:35.015644+00	import	6	f	f	\N
CHUA-GAN-0065	SSD SS 480G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	437	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0066	SSD SS 480G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	438	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
ssd-8tb-122	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u17	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	7	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-123	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u17	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	7	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-124	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u17	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	7	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-125	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u17	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	7	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-022	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u17	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	7	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-023	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u17	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	7	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-024	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u34	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	8	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-025	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u34	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	8	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-126	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u22	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	9	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-127	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u22	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	9	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-128	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u22	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	9	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-129	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u22	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	9	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-026	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u22	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	9	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-027	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u22	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	9	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-130	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	10	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-131	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	10	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-132	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	10	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-133	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	10	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-028	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u36	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	10	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-029	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u36	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	10	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
svr-bd51-u16	MatBao-CA Node 02	server	\N	192.168.201.2	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	2*Intel(R) Xeon(R) Silver 4210R CPU @ 2.40GHz (20 Cores) · RAM 128.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	HP Node 2U	netbox_devices (1).csv	138	{}	2026-09-15 07:35:21.141085+00	2026-09-15 03:25:35.015644+00	import	16	f	f	SGH119WFD6
svr-kho-011	SVR-KHO-011	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	220	{}	2026-09-17 03:40:43.41075+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-012	SVR-KHO-012	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	221	{}	2026-09-17 03:40:43.471802+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-013	SVR-KHO-013	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	222	{}	2026-09-17 03:40:43.540844+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-014	SVR-KHO-014	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	223	{}	2026-09-17 03:40:43.61244+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-015	SVR-KHO-015	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	224	{}	2026-09-17 03:40:43.688922+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-016	SVR-KHO-016	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	225	{}	2026-09-17 03:40:43.755451+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-017	SVR-KHO-017	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	226	{}	2026-09-17 03:40:43.83604+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-018	SVR-KHO-018	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	227	{}	2026-09-17 03:40:43.910319+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-019	SVR-KHO-019	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	228	{}	2026-09-17 03:40:43.983368+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-aq53-u17	Node VNPT102	server	\N	103.138.89.133	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	\N	\N	2*Intel(R) Xeon(R) Gold 5218R CPU @ 2.10GHz (40 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	119	{}	2026-09-15 04:16:43.089349+00	2026-09-15 03:25:35.015644+00	import	17	f	f	ARQGPOO00003
ssd-8tb-134	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u30	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	11	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-135	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u30	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	11	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-136	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u30	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	11	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-137	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u30	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	11	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-030	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u30	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	11	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-031	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u30	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	11	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-032	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u20	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	12	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-033	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u20	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	12	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-480-002	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u26	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	13	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-104	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u24	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	2	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-105	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u24	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	2	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-106	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u24	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	2	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-107	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u24	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	2	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-015	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u24	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	2	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-016	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u24	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	2	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-108	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	3	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-109	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	3	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-110	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	3	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-111	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	3	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-017	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u26	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	3	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-018	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u26	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	3	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-112	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	4	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-113	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	4	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-114	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	4	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-019	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u23	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	4	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-115	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u32	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	5	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-116	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u32	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	5	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-117	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u32	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	5	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-118	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u32	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	5	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-020	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u32	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	5	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-240-021	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u32	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	5	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
svr-p07-u23	Email Node 07 - 128.7	server	\N	103.110.128.7	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	2*Intel(R) Xeon(R) Gold 5318Y CPU @ 2.10GHz (48 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	28	{}	2026-09-15 04:00:16.645195+00	2026-09-15 03:25:35.015644+00	import	23	f	f	A411795X3307876
fw-m08-u42	Fortigate 80F	firewall	\N	\N	\N	\N	CMC Quận 9	CMC Quận 9	2593	10	13	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Fortigate Fortigate 80F	netbox_devices (1).csv	2	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	42	f	f	\N
hsm-m08-u23	Trident 850	hsm	\N	\N	\N	\N	CMC Quận 9	CMC Quận 9	2593	10	13	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Trident Trident	netbox_devices (1).csv	3	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	23	f	f	\N
svr-m08-u25	MIFI Node 03	server	\N	\N	\N	\N	CMC Quận 9	CMC Quận 9	2593	10	13	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	4	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	25	f	f	\N
svr-m08-u28	MIFI Node 02	server	\N	\N	\N	\N	CMC Quận 9	CMC Quận 9	2593	10	13	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	5	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	28	f	f	\N
svr-m08-u31	MIFI Node 01	server	\N	\N	\N	\N	CMC Quận 9	CMC Quận 9	2593	10	13	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	6	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	31	f	f	\N
sto-m08-u34	NAS	storage	\N	\N	\N	\N	CMC Quận 9	CMC Quận 9	2593	10	13	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	NAS 2U NAS 2U	netbox_devices (1).csv	7	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	34	f	f	\N
hsm-m08-u37	HSM	hsm	\N	\N	\N	\N	CMC Quận 9	CMC Quận 9	2593	10	13	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	HSM HSM	netbox_devices (1).csv	8	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	37	f	f	\N
sw-m08-u39	Core Layer 3	switch	\N	\N	\N	\N	CMC Quận 9	CMC Quận 9	2593	10	13	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco WS-C2970G-24TS-E	netbox_devices (1).csv	9	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	39	f	f	\N
fw-m08-u41	Fortigate 100E	firewall	\N	\N	\N	\N	CMC Quận 9	CMC Quận 9	2593	10	13	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Fortigate Fortigate 100E	netbox_devices (1).csv	10	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	41	f	f	\N
CHUA-GAN-0067	SSD SS 480G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	439	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0068	SSD SS 480G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	440	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
ssd-8tb-119	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u29	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	6	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
sw-p07-u41	Storage Switch 02 - 192.168.128.205	switch	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	18	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	41	f	f	\N
sw-p07-u42	Storage Switch 01 - 192.168.128.204	switch	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	19	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	42	f	f	\N
sw-p07-u44	Local Switch 02 - 192.168.128.203	switch	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Cisco 3850	netbox_devices (1).csv	20	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	44	f	f	\N
sw-p07-u45	Local Switch 01 - 192.168.128.202	switch	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Cisco 3850	netbox_devices (1).csv	21	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	45	f	f	\N
sw-p07-u47	Wan2 Cisco 3850 - Stack	switch	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Cisco 3850	netbox_devices (1).csv	22	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	47	f	f	\N
sw-p07-u48	Wan1 Cisco 3850 - 103.110.128.254	switch	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Cisco 3850	netbox_devices (1).csv	23	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	48	f	f	\N
sw-d12-u48	Core-C2960X	switch	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco WS-C2970G-24TS-E	netbox_devices (1).csv	30	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	48	f	f	\N
svr-d12-u29	OPS - COMPUTE	server	\N	10.10.70.11	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz · RAM 188.8 GiB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	odsvps01 · Supermicro Node 2U	netbox_devices (1).csv	24	{}	2026-09-15 07:48:31.254037+00	2026-09-15 03:25:35.015644+00	import	29	f	f	\N
svr-d12-u26	OPS - COMPUTE	server	\N	10.10.70.14	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz · RAM 251.8 GiB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	odsvps03 · Supermicro Node 2U	netbox_devices (1).csv	32	{}	2026-09-15 07:48:31.321338+00	2026-09-15 03:25:35.015644+00	import	26	f	f	\N
svr-d12-u24	OPS - COMPUTE	server	\N	10.10.70.16	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz · RAM 251.7 GiB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	odsvps04 · Supermicro Node 2U	netbox_devices (1).csv	31	{}	2026-09-15 07:48:31.383506+00	2026-09-15 03:25:35.015644+00	import	24	f	f	\N
svr-d12-u36	OPS - CONTROLLER	server	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	control01 · Supermicro Node 2U	netbox_devices (1).csv	35	{}	2026-09-15 07:48:31.516013+00	2026-09-15 03:25:35.015644+00	import	36	f	f	\N
svr-d12-u39	OPS - CONTROLLER	server	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	control02 · Supermicro Node 2U	netbox_devices (1).csv	34	{}	2026-09-15 07:48:31.58845+00	2026-09-15 03:25:35.015644+00	import	39	f	f	\N
svr-d12-u41	OPS - CONTROLLER	server	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	control03 · Supermicro Node 2U	netbox_devices (1).csv	33	{}	2026-09-15 07:48:31.661931+00	2026-09-15 03:25:35.015644+00	import	41	f	f	\N
sw-j6-12	SW N3K - C3064 - STORAGE 2	switch	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	26	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	44	f	f	\N
sw-j6-13	SW N3K - C3064 - STORAGE 1	switch	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	25	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	45	f	f	\N
svr-p07-u28	Email Node 05 - 128.5	server	\N	103.110.128.5	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	2*Intel(R) Xeon(R) Gold 5318Y CPU @ 2.10GHz (48 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	13	{}	2026-09-15 04:00:16.816277+00	2026-09-15 03:25:35.015644+00	import	28	f	f	A411795X3307875
svr-p07-u31	Email Node 04 - 128.4	server	\N	103.110.128.4	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	2*Intel(R) Xeon(R) Gold 5318Y CPU @ 2.10GHz (48 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	14	{}	2026-09-15 04:00:16.887601+00	2026-09-15 03:25:35.015644+00	import	31	f	f	A411795X3307864
svr-p07-u36	Email Node 02 - 128.2	server	\N	103.110.128.2	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	2*Intel(R) Xeon(R) Gold 5318Y CPU @ 2.10GHz (48 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	16	{}	2026-09-15 04:00:17.024601+00	2026-09-15 03:25:35.015644+00	import	36	f	f	A411795X3307870
svr-p07-u38	Email Node 01 - 128.1	server	\N	103.110.128.1	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	\N	\N	2*Intel(R) Xeon(R) Gold 5318Y CPU @ 2.10GHz (48 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	17	{}	2026-09-15 04:00:17.096467+00	2026-09-15 03:25:35.015644+00	import	38	f	f	A411795X3307868
sw-j3-45	SW N3K - 3048 - LOCAL	switch	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus 3048	netbox_devices (1).csv	27	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	47	f	f	\N
CHUA-GAN-0069	SSD SS 960G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	479	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
svr-j2-u17	Server 103.15.50.118	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 1U	netbox_devices (1).csv	38	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	17	f	f	\N
svr-j2-u19	Server 103.15.50.49	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 1U	netbox_devices (1).csv	39	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	19	f	f	\N
svr-j2-u20	Server 112.78.1.41	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 1U	netbox_devices (1).csv	40	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	20	f	f	\N
svr-j2-u22	Server 103.15.51.82	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 1U	netbox_devices (1).csv	41	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	22	f	f	\N
svr-j2-u23	Server 192.168.8.26	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	42	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	23	f	f	\N
svr-j2-u25	Server 192.168.8.25	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	43	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	25	f	f	\N
svr-j2-u27	Server 192.168.8.24	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	44	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	27	f	f	\N
svr-j6-u28	Node Cluster925 - 49.182	server	\N	103.15.49.182	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2660 v4 @ 2.00GHz (28 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	108	{}	2026-09-15 04:32:47.740089+00	2026-09-15 03:25:35.015644+00	import	28	f	f	\N
svr-j5-u24	Node Cluster808 - 49.162	server	\N	103.15.49.162	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4114 CPU @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	67	{}	2026-09-15 04:33:04.438807+00	2026-09-15 03:25:35.015644+00	import	24	f	f	\N
svr-j5-u29	Node Cluster810 - 49.186	server	\N	103.15.49.186	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4114 CPU @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	65	{}	2026-09-15 04:33:04.509262+00	2026-09-15 03:25:35.015644+00	import	29	f	f	\N
svr-j5-u19	Node Cluster806 - 49.79	server	\N	103.15.49.79	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4114 CPU @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	69	{}	2026-09-15 04:33:04.718209+00	2026-09-15 03:25:35.015644+00	import	19	f	f	\N
svr-j3-u18	Ceph 01 - 49.190	server	\N	\N	\N	\N	ODS	ODS	2595	13	17	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	51	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	18	f	f	\N
svr-j3-u16	Ceph 02 - 49.191	server	\N	\N	\N	\N	ODS	ODS	2595	13	17	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	52	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	16	f	f	\N
svr-j3-u13	Ceph 03 - 49.192	server	\N	\N	\N	\N	ODS	ODS	2595	13	17	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	53	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	13	f	f	\N
svr-j3-u11	Ceph 04 - 49.194	server	\N	\N	\N	\N	ODS	ODS	2595	13	17	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	54	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	11	f	f	\N
sto-j3-u06	DAS 01	storage	\N	\N	\N	\N	ODS	ODS	2595	13	17	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	DAS DAS Storage	netbox_devices (1).csv	55	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	6	f	f	\N
sto-j3-u01	DAS 02	storage	\N	\N	\N	\N	ODS	ODS	2595	13	17	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	DAS DAS Storage	netbox_devices (1).csv	56	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	1	f	f	\N
svr-j5-u31	Node Cluster811 - 49.180	server	\N	103.15.49.180	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4114 CPU @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	98	{}	2026-09-15 04:33:04.850354+00	2026-09-15 03:25:35.015644+00	import	31	f	f	\N
CHUA-GAN-0070	SSD SS 960G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	480	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
sw-j2-u46	Sw Storage OPS - 0.24	switch	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	74	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	46	f	f	\N
sw-j2-u45	Sw Access - 0.25	switch	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco WS-C3750E-48PD	netbox_devices (1).csv	75	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	45	f	f	\N
svr-j2-u42	Node OPS 01 - 48.251	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 3U	netbox_devices (1).csv	76	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	42	f	f	\N
svr-j4-u18	Node ClusterX123 - 49.176	server	\N	103.15.49.176	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) Gold 5218 CPU @ 2.30GHz (32 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	59	{}	2026-09-15 04:30:55.559029+00	2026-09-15 03:25:35.015644+00	import	18	f	f	\N
svr-j3-u38	Node ClusterX111 - 49.164	server	\N	103.15.49.164	\N	\N	ODS	ODS	2595	13	17	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	47	{}	2026-09-15 04:30:55.924395+00	2026-09-15 03:25:35.015644+00	import	38	f	f	\N
svr-j4-u03	Node ClusterX114 - 49.169	server	\N	103.15.49.169	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz (16 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	64	{}	2026-09-15 04:30:56.137474+00	2026-09-15 03:25:35.015644+00	import	3	f	f	KZVXKRR00003
svr-j4-u05	Node ClusterX115 - 49.165	server	\N	103.15.49.165	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) Gold 5218 CPU @ 2.30GHz (32 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	61	{}	2026-09-15 04:30:56.253431+00	2026-09-15 03:25:35.015644+00	import	5	f	f	\N
svr-j3-u29	Node ClusterX102 - 49.42	server	\N	103.15.49.42	\N	\N	ODS	ODS	2595	13	17	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 3U	netbox_devices (1).csv	50	{}	2026-09-15 04:30:56.436367+00	2026-09-15 03:25:35.015644+00	import	29	f	f	A19795827508276
svr-j4-u08	Node ClusterX116 - 49.204	server	\N	103.15.49.204	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	60	{}	2026-09-15 04:30:56.505139+00	2026-09-15 03:25:35.015644+00	import	8	f	f	\N
svr-j3-u24	Node Cluster X1 - 49.141	server	\N	103.15.49.141	\N	\N	ODS	ODS	2595	13	17	\N	\N	2*Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz (16 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	58	{}	2026-09-15 04:30:56.713736+00	2026-09-15 03:25:35.015644+00	import	24	f	f	\N
svr-j3-u26	Node ClusterX1 - 49.142	server	\N	103.15.49.142	\N	\N	ODS	ODS	2595	13	17	\N	\N	2*Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz (16 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	57	{}	2026-09-15 04:30:56.778548+00	2026-09-15 03:25:35.015644+00	import	26	f	f	\N
svr-j5-u11	Node Cluster803 - 49.75	server	\N	103.15.49.75	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4114 CPU @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	72	{}	2026-09-15 04:33:04.981992+00	2026-09-15 03:25:35.015644+00	import	11	f	f	\N
svr-j4-u13	Node ClusterX119 - 49.202	server	\N	103.15.49.202	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	63	{}	2026-09-15 04:30:55.192852+00	2026-09-15 03:25:35.015644+00	import	13	f	f	\N
svr-j5-u26	Node Cluster809 - 49.160	server	\N	103.15.49.160	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4114 CPU @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	66	{}	2026-09-15 04:33:05.106588+00	2026-09-15 03:25:35.015644+00	import	26	f	f	\N
svr-j2-u39	Node OPS 02 - 48.252	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 3U	netbox_devices (1).csv	77	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	39	f	f	\N
svr-j2-u35	Node OPS 03 - 48.253	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 3U	netbox_devices (1).csv	78	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	35	f	f	\N
sw-j3-u46	Sw Core Layer 3 - 0.29	switch	\N	\N	\N	\N	ODS	ODS	2595	13	17	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus 3048	netbox_devices (1).csv	79	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	46	f	f	\N
sw-j4-u46	Sw Access - 0.21	switch	\N	\N	\N	\N	ODS	ODS	2595	13	18	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco WS-C3750E-48PD	netbox_devices (1).csv	80	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	46	f	f	\N
sw-j4-u44	Sw Storage ClusterX1 - 0.17	switch	\N	\N	\N	\N	ODS	ODS	2595	13	18	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	81	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	44	f	f	\N
sw-j4-u43	Sw Storage ClusterX1 - 0.18	switch	\N	\N	\N	\N	ODS	ODS	2595	13	18	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	82	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	43	f	f	\N
svr-j6-u20	Node Cluster913 - 49.37	server	\N	103.15.49.37	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	114	{}	2026-09-15 04:32:47.193097+00	2026-09-15 03:25:35.015644+00	import	20	f	f	\N
svr-j6-u23	Node Cluster914 - 49.36	server	\N	103.15.49.36	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	116	{}	2026-09-15 04:32:47.348317+00	2026-09-15 03:25:35.015644+00	import	23	f	f	\N
svr-j6-u35	Node Cluster929 - 49.40	server	\N	103.15.49.40	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz (16 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	104	{}	2026-09-15 04:32:47.412593+00	2026-09-15 03:25:35.015644+00	import	35	f	f	KZVXKRR00004
svr-j6-u18	Node Cluster910 - 49.65	server	\N	103.15.49.65	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	115	{}	2026-09-15 04:32:47.535292+00	2026-09-15 03:25:35.015644+00	import	18	f	f	\N
sw-j5-u43	Sw Access - 0.22	switch	\N	\N	\N	\N	ODS	ODS	2595	13	19	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco WS-C3750E-48PD	netbox_devices (1).csv	93	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	43	f	f	\N
sw-j5-u40	Sw Storage Cluster8 - 0.15	switch	\N	\N	\N	\N	ODS	ODS	2595	13	19	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	94	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	40	f	f	\N
sw-j5-u39	Sw Storage Cluster8 - 0.16	switch	\N	\N	\N	\N	ODS	ODS	2595	13	19	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	95	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	39	f	f	\N
CHUA-GAN-0071	SSD SS 960G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	481	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0072	SSD SS 960G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	482	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
sw-j6-u46	Sw Access - 0.11	switch	\N	\N	\N	\N	ODS	ODS	2595	13	20	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco WS-C2970G-24TS-E	netbox_devices (1).csv	99	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	46	f	f	\N
sw-j6-u44	Sw Storage Cluster9 - 0.13	switch	\N	\N	\N	\N	ODS	ODS	2595	13	20	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	100	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	44	f	f	\N
sw-j6-u43	Sw Storage Cluster9 - 0.14	switch	\N	\N	\N	\N	ODS	ODS	2595	13	20	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	101	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	43	f	f	\N
sw-j3-u40	Sw access	switch	\N	\N	\N	\N	ODS	ODS	2595	13	17	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco WS-C2970G-24TS-E	netbox_devices (1).csv	106	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	40	f	f	\N
svr-j2-u15	Server 113.78.1.21	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 1U	netbox_devices (1).csv	110	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	15	f	f	\N
svr-j2-u02	Server 125.253.116.254	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	111	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	2	f	f	\N
svr-j2-u04	Server 125.253.116.7	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	112	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	4	f	f	\N
svr-j2-u13	Server 112.78.3.42	server	\N	\N	\N	\N	ODS	ODS	2595	13	16	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	113	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	13	f	f	\N
svr-j4-u25	Node ClusterX126 - 49.184	server	\N	103.15.49.184	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) Gold 5218 CPU @ 2.30GHz (32 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	89	{}	2026-09-15 04:30:55.660118+00	2026-09-15 03:25:35.015644+00	import	25	f	f	\N
svr-j4-u33	Node ClusterX132 - 49.48	server	\N	103.15.49.48	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	86	{}	2026-09-15 04:30:55.837713+00	2026-09-15 03:25:35.015644+00	import	33	f	f	\N
svr-j4-u35	Node ClusterX131 - 49.80	server	\N	103.15.49.80	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	85	{}	2026-09-15 04:30:56.004847+00	2026-09-15 03:25:35.015644+00	import	35	f	f	\N
svr-j4-u10	Node ClusterX118 - 49.201	server	\N	103.15.49.201	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) Gold 5118 CPU @ 2.30GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	92	{}	2026-09-15 04:30:56.195198+00	2026-09-15 03:25:35.015644+00	import	10	f	f	\N
svr-j4-u28	Node ClusterX127 - 49.185	server	\N	103.15.49.185	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) Gold 5218 CPU @ 2.30GHz (32 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	88	{}	2026-09-15 04:30:56.575141+00	2026-09-15 03:25:35.015644+00	import	28	f	f	\N
svr-j6-u40	Node Cluster927 - 49.38	server	\N	103.15.49.38	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2630 v4 @ 2.20GHz (20 Cores) · RAM 224.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	102	{}	2026-09-15 04:32:47.595748+00	2026-09-15 03:25:35.015644+00	import	40	f	f	\N
svr-j4-u40	Node ClusterX129 - 49.81	server	\N	103.15.49.81	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	83	{}	2026-09-15 04:30:55.379303+00	2026-09-15 03:25:35.015644+00	import	40	f	f	\N
svr-j6-u38	Node Cluster928 - 49.39	server	\N	103.15.49.39	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	103	{}	2026-09-15 04:32:47.658965+00	2026-09-15 03:25:35.015644+00	import	38	f	f	\N
svr-j6-u07	Cluster122 - 49.8	server	\N	103.15.49.8	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2630 v4 @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	37	{}	2026-09-15 04:32:47.867964+00	2026-09-15 03:25:35.015644+00	import	7	f	f	\N
svr-j5-u34	Node Cluster812 - 49.187	server	\N	103.15.49.187	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4114 CPU @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	97	{}	2026-09-15 04:33:04.779171+00	2026-09-15 03:25:35.015644+00	import	34	f	f	\N
svr-j5-u14	Node Cluster804 - 49.76	server	\N	103.15.49.76	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4114 CPU @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	71	{}	2026-09-15 04:33:04.912695+00	2026-09-15 03:25:35.015644+00	import	14	f	f	\N
svr-j6-u09	Cluster121 - 49.7	server	\N	103.15.49.7	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2630 v4 @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	118	{}	2026-09-15 04:32:47.808938+00	2026-09-15 03:25:35.015644+00	import	9	f	f	\N
svr-j6-u04	Cluster123 - 49.9	server	\N	103.15.49.9	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2630 v4 @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	117	{}	2026-09-15 04:32:47.931917+00	2026-09-15 03:25:35.015644+00	import	4	f	f	\N
sw-aq53-u32	Sw Storage (2)	switch	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	125	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	32	f	f	\N
sw-aq53-u33	Sw Storage (1)	switch	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	126	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	33	f	f	\N
sw-aq53-u35	Sw Local Layer3 (2)	switch	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus 3048	netbox_devices (1).csv	127	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	35	f	f	\N
sw-aq53-u36	Sw Local Layer3 (1)	switch	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus 3048	netbox_devices (1).csv	128	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	36	f	f	\N
hsm-bd51-u04	Trident 844	hsm	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Trident Trident	netbox_devices (1).csv	129	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	4	f	f	\N
hsm-bd51-u06	Trident 846	hsm	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Trident Trident	netbox_devices (1).csv	130	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	6	f	f	\N
fw-bd51-u08	Fortigate 100E (Passive)	firewall	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Fortigate Fortigate 100E	netbox_devices (1).csv	131	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	8	f	f	\N
fw-bd51-u09	Fortigate 100E (Active)	firewall	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Fortigate Fortigate 100E	netbox_devices (1).csv	132	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	9	f	f	\N
fw-bd51-u10	Fortigate 80F (Active|Stanby)	firewall	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Fortigate Fortigate 80F	netbox_devices (1).csv	133	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	10	f	f	\N
svr-aq54-u21	Backup Node	server	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	134	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	21	f	f	\N
sw-bd51-u11	matBao-CA CoreSW 02	switch	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco C3750	netbox_devices (1).csv	135	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	11	f	f	\N
sw-bd51-u12	matBao-CA CoreSW 01	switch	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco C3750	netbox_devices (1).csv	136	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	12	f	f	\N
CHUA-GAN-0073	SSD SS 960G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	483	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
sw-bd51-u22	MatBao-CA Sw Storage 02	switch	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	140	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	22	f	f	\N
sw-bd51-u23	MatBao-CA Sw Storage 01	switch	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco Nexus C3064	netbox_devices (1).csv	141	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	23	f	f	\N
hsm-bd51-u27	HSM 3	hsm	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	HSM HSM	netbox_devices (1).csv	142	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	27	f	f	\N
hsm-bd51-u29	HSM 2	hsm	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	HSM HSM	netbox_devices (1).csv	143	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	29	f	f	\N
hsm-bd51-u31	HSM 1	hsm	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	HSM HSM	netbox_devices (1).csv	144	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	31	f	f	\N
sto-bd51-u33	DC MatBao-CA NAS	storage	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	NAS 2U NAS 2U	netbox_devices (1).csv	145	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	33	f	f	\N
svr-bd51-u13	MatBao-CA Node 01	server	\N	192.168.201.1	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	2*Intel(R) Xeon(R) Silver 4210R CPU @ 2.40GHz (20 Cores) · RAM 128.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	HP Node 2U	netbox_devices (1).csv	137	{}	2026-09-15 07:35:21.027152+00	2026-09-15 03:25:35.015644+00	import	13	f	f	SGH119WFD3
CHUA-GAN-0074	SSD SS 960G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	484	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
svr-bd51-u37	MatBao-CA Node 05	server	\N	192.168.201.5	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	2*Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz (16 Cores) · RAM 128.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	147	{}	2026-09-15 04:40:41.409416+00	2026-09-15 03:25:35.015644+00	import	37	f	f	KZVXKRR00002
svr-aq53-u26	Node VNPT103	server	\N	103.138.89.134	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	\N	\N	2*Intel(R) Xeon(R) Gold 5218R CPU @ 2.10GHz (40 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	123	{}	2026-09-15 04:16:42.7414+00	2026-09-15 03:25:35.015644+00	import	26	f	f	ARQGPOO00004
svr-aq54-u32	Node VNPT109	server	\N	103.138.89.140	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	\N	\N	2*Intel(R) Xeon(R) Gold 5218R CPU @ 2.10GHz (40 Cores) · RAM 512.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	152	{}	2026-09-15 04:16:42.901941+00	2026-09-15 03:25:35.015644+00	import	32	f	f	AHRMTMR00003
svr-aq54-u29	Node VNPT110	server	\N	103.138.89.141	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	\N	\N	2*Intel(R) Xeon(R) Gold 5118 CPU @ 2.30GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	151	{}	2026-09-15 04:16:42.994957+00	2026-09-15 03:25:35.015644+00	import	29	f	f	\N
svr-aq53-u22	Node VNPT105	server	\N	103.138.89.136	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	\N	\N	2*Intel(R) Xeon(R) Gold 5218R CPU @ 2.10GHz (40 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	121	{}	2026-09-15 04:16:43.224942+00	2026-09-15 03:25:35.015644+00	import	22	f	f	ARQGPOO00001
svr-aq53-u30	Node VNPT101	server	\N	103.138.89.132	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	\N	\N	2*Intel(R) Xeon(R) Gold 5218R CPU @ 2.10GHz (40 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	124	{}	2026-09-15 04:16:43.383921+00	2026-09-15 03:25:35.015644+00	import	30	f	f	ARQGPOO00002
svr-aq53-u20	Node VNPT106	server	\N	103.138.89.137	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	\N	\N	2*Intel(R) Xeon(R) Gold 5218 CPU @ 2.30GHz (32 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	120	{}	2026-09-15 04:16:43.489159+00	2026-09-15 03:25:35.015644+00	import	20	f	f	\N
svr-bd51-u39	MatBao-CA Node 04	server	\N	192.168.201.4	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	2*Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz (16 Cores) · RAM 128.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	148	{}	2026-09-15 04:40:41.514536+00	2026-09-15 03:25:35.015644+00	import	39	f	f	\N
svr-bd51-u19	MatBao-CA Node 03	server	\N	192.168.201.3	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	\N	\N	2*Intel(R) Xeon(R) Silver 4210R CPU @ 2.40GHz (20 Cores) · RAM 128.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	HP Node 2U	netbox_devices (1).csv	139	{}	2026-09-15 07:35:21.227706+00	2026-09-15 03:25:35.015644+00	import	19	f	f	SGH203XGXM
sw-aq54-u39	Switch Access	switch	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	\N	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cisco WS-C3750E-24PD	netbox_devices (1).csv	155	{}	2026-09-15 03:25:35.015644+00	2026-09-15 03:25:35.015644+00	import	39	f	f	\N
svr-aq54-u34	Node VNPT108	server	\N	103.138.89.139	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	\N	\N	2*Intel(R) Xeon(R) Gold 5218R CPU @ 2.10GHz (40 Cores) · RAM 512.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	153	{}	2026-09-15 04:16:43.157532+00	2026-09-15 03:25:35.015644+00	import	34	f	f	AHRMTMR00001
svr-aq54-u36	Node VNPT107	server	\N	103.138.89.138	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	\N	\N	2*Intel(R) Xeon(R) Gold 5218R CPU @ 2.10GHz (40 Cores) · RAM 512.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	154	{}	2026-09-15 04:16:43.288152+00	2026-09-15 03:25:35.015644+00	import	36	f	f	AHRMTMR00002
svr-aq54-u26	Node VNPT111	server	\N	103.138.89.142	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	\N	\N	2*Intel(R) Xeon(R) Gold 5118 CPU @ 2.30GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	150	{}	2026-09-15 04:16:43.568672+00	2026-09-15 03:25:35.015644+00	import	26	f	f	\N
ssd-8tb-120	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u29	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	6	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-8tb-121	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u29	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	6	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
ssd-480-001	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	22	svr-aq54-u29	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_da4c4f39-010a-4512-becd-bad507d133ae.csv	6	{}	2026-09-15 04:16:52.497601+00	2026-09-15 04:16:52.497601+00	import	\N	f	f	\N
svr-j3-u41	Node ClusterX112 - 49.171	server	\N	103.15.49.171	\N	\N	ODS	ODS	2595	13	17	\N	\N	2*Intel(R) Xeon(R) CPU E5-2630 v4 @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	46	{}	2026-09-15 04:30:55.122063+00	2026-09-15 03:25:35.015644+00	import	41	f	f	\N
svr-j4-u23	Node ClusterX125 - 49.183	server	\N	103.15.49.183	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) CPU E5-2660 v4 @ 2.00GHz (28 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	90	{}	2026-09-15 04:30:55.25675+00	2026-09-15 03:25:35.015644+00	import	23	f	f	\N
svr-j4-u38	Node ClusterX130 - 49.67	server	\N	103.15.49.67	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	84	{}	2026-09-15 04:30:55.316218+00	2026-09-15 03:25:35.015644+00	import	38	f	f	\N
svr-j4-u30	Node ClusterX128 - 49.253	server	\N	103.15.49.253	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	87	{}	2026-09-15 04:30:55.748554+00	2026-09-15 03:25:35.015644+00	import	30	f	f	\N
svr-j3-u43	Node ClusterX113 - 49.167	server	\N	103.15.49.167	\N	\N	ODS	ODS	2595	13	17	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	45	{}	2026-09-15 04:30:56.070651+00	2026-09-15 03:25:35.015644+00	import	43	f	f	\N
svr-j4-u20	Node ClusterX124 - 49.177	server	\N	103.15.49.177	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) Gold 5218 CPU @ 2.30GHz (32 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	91	{}	2026-09-15 04:30:56.316962+00	2026-09-15 03:25:35.015644+00	import	20	f	f	\N
svr-j3-u32	Node ClusterX113 - 49.43	server	\N	103.15.49.43	\N	\N	ODS	ODS	2595	13	17	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650L v4 @ 1.70GHz (28 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 3U	netbox_devices (1).csv	49	{}	2026-09-15 04:30:56.377423+00	2026-09-15 03:25:35.015644+00	import	32	f	f	A19795827313746
svr-j4-u15	Node ClusterX120 - 49.203	server	\N	103.15.49.203	\N	\N	ODS	ODS	2595	13	18	\N	\N	2*Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	62	{}	2026-09-15 04:30:56.63961+00	2026-09-15 03:25:35.015644+00	import	15	f	f	\N
CHUA-GAN-0075	SSD SS 960G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	494	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
CHUA-GAN-0076	SSD SS 960G	disk	component	\N	disk	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	495	{}	2026-09-17 03:42:28.389948+00	2026-09-17 03:42:28.389948+00	import	\N	t	t	\N
ssd-240-034	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u41	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	2	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
das-kho-003	DAS-KHO-003	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	253	{}	2026-09-17 03:40:40.109476+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
das-kho-004	DAS-KHO-004	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	254	{}	2026-09-17 03:40:40.185525+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
das-kho-005	DAS-KHO-005	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	255	{}	2026-09-17 03:40:40.256847+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
das-kho-006	DAS-KHO-006	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	256	{}	2026-09-17 03:40:40.339058+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
das-kho-007	DAS-KHO-007	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	257	{}	2026-09-17 03:40:40.436584+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
das-kho-008	DAS-KHO-008	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	258	{}	2026-09-17 03:40:40.533896+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-028	SVR-KHO-028	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	237	{}	2026-09-17 03:40:44.646018+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-029	SVR-KHO-029	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	238	{}	2026-09-17 03:40:44.713395+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-033	SVR-KHO-033	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	242	{}	2026-09-17 03:40:44.787515+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-034	SVR-KHO-034	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	243	{}	2026-09-17 03:40:44.853854+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-040	SVR-KHO-040	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	249	{}	2026-09-17 03:40:44.918404+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-041	SVR-KHO-041	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	250	{}	2026-09-17 03:40:45.014499+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-042	SVR-KHO-042	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	264	{}	2026-09-17 03:40:45.093928+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-043	SVR-KHO-043	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	265	{}	2026-09-17 03:40:45.181903+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-044	SVR-KHO-044	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	266	{}	2026-09-17 03:40:45.272302+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
sw-kho-03	SW-KHO-03	switch	component	\N	switch	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	261	{}	2026-09-17 03:40:45.606382+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
sw-kho-04	SW-KHO-04	switch	component	\N	switch	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	262	{}	2026-09-17 03:40:45.7047+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
sw-kho-05	SW-KHO-05	switch	component	\N	switch	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	263	{}	2026-09-17 03:40:45.785053+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-j3-u36	Node ClusterX110 - 49.66	server	\N	103.15.49.66	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	2*Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz (16 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	48	{}	2026-10-12 07:09:13.870417+00	2026-09-15 03:25:35.015644+00	import	21	f	f	\N
hdd-4tb-002	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-j3-u36	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	7	{}	2026-10-12 07:09:13.870417+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-003	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-j3-u36	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	7	{}	2026-10-12 07:09:13.870417+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-004	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-j3-u36	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	7	{}	2026-10-12 07:09:13.870417+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
raid-240-002	Volume RAID 239.00GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-j3-u36	\N	239.00GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	7	{}	2026-10-12 07:09:13.870417+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-480-003	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-j3-u36	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	7	{}	2026-10-12 07:09:13.870417+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-480-004	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-j3-u36	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	7	{}	2026-10-12 07:09:13.870417+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-001	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-j3-u36	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	7	{}	2026-10-12 07:09:13.870417+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
cap-10-0021	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	289	{}	2026-09-17 03:40:31.370429+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0022	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	290	{}	2026-09-17 03:40:31.46238+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0023	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	291	{}	2026-09-17 03:40:31.544071+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0024	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	292	{}	2026-09-17 03:40:31.631389+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0025	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	293	{}	2026-09-17 03:40:31.704426+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0026	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	294	{}	2026-09-17 03:40:31.772461+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0027	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	295	{}	2026-09-17 03:40:31.845343+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0028	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	296	{}	2026-09-17 03:40:31.930005+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0029	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	297	{}	2026-09-17 03:40:32.032781+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0030	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	298	{}	2026-09-17 03:40:32.105939+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0031	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	299	{}	2026-09-17 03:40:32.170424+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0032	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	300	{}	2026-09-17 03:40:32.231096+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0033	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	301	{}	2026-09-17 03:40:32.290378+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0034	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	302	{}	2026-09-17 03:40:32.352061+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0035	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	303	{}	2026-09-17 03:40:32.415645+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0036	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	304	{}	2026-09-17 03:40:32.488213+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0047	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	315	{}	2026-09-17 03:40:32.580957+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0048	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	316	{}	2026-09-17 03:40:32.667744+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0049	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	317	{}	2026-09-17 03:40:32.73717+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0050	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	318	{}	2026-09-17 03:40:32.80061+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0051	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	319	{}	2026-09-17 03:40:32.86802+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0052	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	320	{}	2026-09-17 03:40:32.934249+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0053	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	321	{}	2026-09-17 03:40:33.006009+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0054	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	322	{}	2026-09-17 03:40:33.090976+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0055	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	323	{}	2026-09-17 03:40:33.166948+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0056	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	324	{}	2026-09-17 03:40:33.23049+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-40-0017	cáp 40Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	279	{}	2026-09-17 03:40:37.485808+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-40-0018	cáp 40Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	280	{}	2026-09-17 03:40:37.550496+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-40-0019	cáp 40Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	281	{}	2026-09-17 03:40:37.61146+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-40-0020	cáp 40Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	282	{}	2026-09-17 03:40:37.67365+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-j2-2324	SVR-J2-2324	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	271	{}	2026-09-17 03:40:42.045191+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-j2-2526	SVR-J2-2526	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	272	{}	2026-09-17 03:40:42.113517+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-j2-2728	SVR-J2-2728	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	pending_disposal	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	273	{}	2026-09-17 03:40:42.179406+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-j2-2930	SVR-J2-2930	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	274	{}	2026-09-17 03:40:42.241477+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-j2-3132	SVR-J2-3132	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	275	{}	2026-09-17 03:40:42.311081+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-j2-3334	SVR-J2-3334	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	276	{}	2026-09-17 03:40:42.389758+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-045	SVR-KHO-045	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	267	{}	2026-09-17 03:40:45.348859+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-046	SVR-KHO-046	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	268	{}	2026-09-17 03:40:45.437818+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-047	SVR-KHO-047	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	269	{}	2026-09-17 03:40:45.524334+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
ssd-960-004	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u19	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	2	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-005	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u19	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	2	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-006	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u19	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	2	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-007	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u19	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	2	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-008	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u19	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	2	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-009	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u19	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	2	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-480-019	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u19	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	2	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-010	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u35	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	3	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-011	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u35	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	3	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
raid-240-004	Volume RAID 239.00GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u20	\N	239.00GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	2	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-065	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u30	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	3	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-066	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u30	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	3	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-067	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u30	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	3	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-068	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u30	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	3	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-069	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u30	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	3	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-070	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u30	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	3	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
raid-480-001	Volume RAID 479.00GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u30	\N	479.00GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	3	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-071	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u23	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	4	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-072	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u23	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	4	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-073	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u23	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	4	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-074	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u23	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	4	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-075	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u23	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	4	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-076	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u23	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	4	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
raid-960-001	Volume RAID 999.00GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u23	\N	999.00GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	4	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-240-061	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u35	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	5	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-077	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u35	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	5	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-078	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u35	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	5	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-079	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u35	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	5	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-080	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u35	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	5	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-081	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u35	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	5	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
cap-10-0059	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	327	{}	2026-09-17 03:40:33.42859+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0060	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	328	{}	2026-09-17 03:40:33.498001+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0061	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	329	{}	2026-09-17 03:40:33.562899+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0062	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	330	{}	2026-09-17 03:40:33.638152+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0063	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	331	{}	2026-09-17 03:40:33.71118+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
ssd-2tb-082	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u35	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	5	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-240-062	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u33	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	6	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-083	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u33	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	6	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-084	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u33	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	6	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-085	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u33	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	6	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-086	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u33	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	6	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-087	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u33	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	6	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-088	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u33	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	6	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-240-063	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u18	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	7	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-089	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u18	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	7	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-090	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u18	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	7	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-091	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u18	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	7	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-092	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u18	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	7	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-093	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u18	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	7	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-094	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u18	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	7	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-240-064	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u40	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	8	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-095	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u40	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	8	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-096	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u40	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	8	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-097	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u40	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	8	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-098	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u40	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	8	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-099	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u40	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	8	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-100	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u40	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	8	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-240-065	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u38	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	9	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-101	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u38	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	9	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-102	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u38	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	9	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-103	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u38	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	9	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-104	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u38	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	9	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-105	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u38	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	9	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-106	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u38	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	9	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-240-066	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u28	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	10	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-107	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u28	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	10	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-108	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u28	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	10	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-109	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u28	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	10	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-110	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u28	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	10	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-111	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u28	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	10	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-2tb-112	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u28	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	10	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-240-067	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u09	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	11	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-240-068	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u07	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	12	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
ssd-240-069	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u04	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	13	{}	2026-09-15 04:32:48.404488+00	2026-09-15 04:32:48.404488+00	import	\N	f	f	\N
svr-j5-u21	Node Cluster807 - 49.72	server	\N	103.15.49.72	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4114 CPU @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	68	{}	2026-09-15 04:33:05.039642+00	2026-09-15 03:25:35.015644+00	import	21	f	f	\N
ssd-960-012	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u35	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	3	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-013	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u35	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	3	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-014	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u35	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	3	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-015	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u35	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	3	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-480-020	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u35	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	3	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-016	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u37	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	4	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-017	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u37	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	4	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-018	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u37	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	4	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-019	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u37	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	4	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-020	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u37	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	4	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-021	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u37	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	4	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-240-092	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u37	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	4	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-022	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u39	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	5	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-023	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u39	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	5	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-024	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u39	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	5	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-025	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u39	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	5	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-026	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u39	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	5	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-027	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u39	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	5	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-240-093	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u39	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	5	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-028	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u16	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	6	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-029	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u16	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	6	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-030	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u16	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	6	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-031	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u16	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	6	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-032	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u16	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	6	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-033	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u16	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	6	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-480-021	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u16	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	6	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-034	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u13	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	7	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-035	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u13	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	7	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
svr-j5-u36	Node Cluster813 - 49.188	server	\N	103.15.49.188	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4214 CPU @ 2.20GHz (24 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	96	{}	2026-09-15 04:33:04.310457+00	2026-09-15 03:25:35.015644+00	import	36	f	f	\N
ssd-960-036	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u13	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	7	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-037	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u13	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	7	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-038	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u13	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	7	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-960-039	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u13	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	7	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
ssd-480-022	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u13	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2ca3c5d7-628b-44b7-ab90-d0e48c30be37.csv	7	{}	2026-09-15 04:40:42.097909+00	2026-09-15 04:40:42.097909+00	import	\N	f	f	\N
raid-240-001	Volume RAID 239.51GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u13	\N	239.51GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	3	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-035	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u23	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	4	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-001	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u23	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	4	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-002	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u23	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	4	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-003	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u23	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	4	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-004	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u23	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	4	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-005	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u23	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	4	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-006	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u23	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	4	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-036	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u38	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	5	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-037	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u40	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	6	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-007	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u40	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	6	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-008	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u40	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	6	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-009	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u40	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	6	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-010	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u40	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	6	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-011	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u40	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	6	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-012	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u40	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	6	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-038	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u18	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	8	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-039	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u18	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	8	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
cap-10-0067	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	335	{}	2026-09-17 03:40:34.032101+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0068	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	336	{}	2026-09-17 03:40:34.098897+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0069	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	337	{}	2026-09-17 03:40:34.168256+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0070	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	338	{}	2026-09-17 03:40:34.245156+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
ssd-240-040	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u25	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	9	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-041	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u25	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	9	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-480-005	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u25	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	9	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-480-006	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u25	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	9	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-005	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u25	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	9	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-006	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u25	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	9	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-007	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u25	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	9	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-008	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u25	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	9	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-960-001	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u30	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	10	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-480-007	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u30	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	10	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-480-008	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u30	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	10	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-009	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u30	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	10	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-010	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u30	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	10	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-011	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u30	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	10	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-012	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u30	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	10	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-960-002	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u33	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	11	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-042	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u33	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	11	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-480-009	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u33	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	11	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-013	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u33	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	11	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-014	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u33	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	11	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-015	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u33	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	11	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-016	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u33	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	11	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-043	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u38	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	12	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-480-010	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u38	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	12	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-480-011	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u38	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	12	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-017	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u38	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	12	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-018	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u38	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	12	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-019	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u38	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	12	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-020	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u38	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	12	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-960-003	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u35	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	13	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-044	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u35	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	13	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-480-012	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u35	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	13	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-021	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u35	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	13	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-022	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u35	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	13	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-023	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u35	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	13	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-024	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u35	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	13	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-045	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u43	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	14	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-013	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u43	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	14	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-014	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u43	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	14	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-015	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u43	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	14	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-016	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u43	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	14	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-017	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u43	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	14	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-046	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u03	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	15	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-480-013	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u03	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	15	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-480-014	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u03	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	15	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-025	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u03	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	15	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-026	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u03	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	15	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-027	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u03	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	15	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
hdd-4tb-028	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u03	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	15	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-018	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u10	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	16	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-019	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u10	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	16	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-020	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u10	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	16	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-021	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u10	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	16	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-022	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u10	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	16	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-023	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u10	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	16	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
raid-240-003	Volume RAID 239.00GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u10	\N	239.00GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	16	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-047	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u05	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	17	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-048	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u05	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	17	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-024	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u05	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	17	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-025	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u05	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	17	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-026	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u05	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	17	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-027	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u05	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	17	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-028	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u05	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	17	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-029	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u05	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	17	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-049	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u20	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	18	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-050	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u20	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	18	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-030	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u20	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	18	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-031	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u20	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	18	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-032	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u20	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	18	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-033	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u20	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	18	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-034	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u20	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	18	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-035	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u20	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	18	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-051	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u32	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	19	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-052	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u32	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	19	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-036	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u32	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	19	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-037	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u32	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	19	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-038	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u32	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	19	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-039	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u32	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	19	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-040	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u32	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	19	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-041	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u32	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	19	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-053	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u29	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	20	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-054	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u29	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	20	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-042	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	20	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-043	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	20	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-044	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	20	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-045	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	20	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-046	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	20	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-047	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	20	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-055	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u08	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	21	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-048	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u08	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	21	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-049	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u08	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	21	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-050	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u08	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	21	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-051	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u08	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	21	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-052	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u08	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	21	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-056	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u28	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	22	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-057	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u28	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	22	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-053	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u28	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	22	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-054	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u28	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	22	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-055	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u28	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	22	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-056	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u28	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	22	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-057	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u28	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	22	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-058	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u28	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	22	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-058	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u15	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	23	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-059	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u15	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	23	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-060	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u15	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	23	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-061	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u15	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	23	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-062	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u15	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	23	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-063	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u15	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	23	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-2tb-064	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u15	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	23	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-059	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u24	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	24	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
ssd-240-060	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	17	svr-j3-u26	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_a7190e73-05e6-4bc2-b12f-ca88d166c86b.csv	25	{}	2026-09-15 04:31:07.129724+00	2026-09-15 04:31:07.129724+00	import	\N	f	f	\N
svr-j5-u16	Node Cluster805 - 49.77	server	\N	103.15.49.77	\N	\N	ODS	ODS	2595	13	19	\N	\N	2*Intel(R) Xeon(R) Silver 4114 CPU @ 2.20GHz (20 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	70	{}	2026-09-15 04:33:04.372149+00	2026-09-15 03:25:35.015644+00	import	16	f	f	\N
ssd-2tb-275	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-276	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-277	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-278	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-960-040	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-960-041	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-095	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-096	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-029	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-030	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-031	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-032	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-033	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-034	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-279	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-280	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-281	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-282	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-960-042	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-960-043	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-097	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-098	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-035	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-036	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-037	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-038	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-039	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-040	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-283	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-284	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-285	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-286	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
svr-j6-u25	Node Cluster924 - 49.220	server	\N	103.15.49.220	\N	\N	ODS	ODS	2595	13	20	\N	\N	2*Intel(R) Xeon(R) CPU E5-2660 v4 @ 2.00GHz (28 Cores) · RAM 256.0GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Supermicro Node 2U	netbox_devices (1).csv	109	{}	2026-09-15 07:35:21.299114+00	2026-09-15 03:25:35.015644+00	import	25	f	f	\N
ssd-240-094	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u25	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	14	{}	2026-09-15 04:47:25.043196+00	2026-09-15 04:47:25.043196+00	import	\N	f	f	\N
ssd-2tb-269	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u25	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	14	{}	2026-09-15 04:47:25.043196+00	2026-09-15 04:47:25.043196+00	import	\N	f	f	\N
ssd-2tb-270	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u25	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	14	{}	2026-09-15 04:47:25.043196+00	2026-09-15 04:47:25.043196+00	import	\N	f	f	\N
ssd-2tb-271	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u25	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	14	{}	2026-09-15 04:47:25.043196+00	2026-09-15 04:47:25.043196+00	import	\N	f	f	\N
ssd-2tb-272	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u25	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	14	{}	2026-09-15 04:47:25.043196+00	2026-09-15 04:47:25.043196+00	import	\N	f	f	\N
ssd-2tb-273	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u25	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	14	{}	2026-09-15 04:47:25.043196+00	2026-09-15 04:47:25.043196+00	import	\N	f	f	\N
ssd-2tb-274	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u25	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_c8a295bd-64a2-4646-bf5b-1dc1565450a3.csv	14	{}	2026-09-15 04:47:25.043196+00	2026-09-15 04:47:25.043196+00	import	\N	f	f	\N
ssd-960-044	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-960-045	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-099	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-100	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-041	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-042	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-043	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-044	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-045	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-046	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-287	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-288	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-289	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-290	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-960-046	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
cab-10g-105	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-106	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-107	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-108	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-109	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	sw-j6-u43	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-011	Cáp 20Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	sw-j6-u43	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
ssd-960-047	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-101	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-102	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-047	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-048	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-049	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-050	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-291	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-292	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-293	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-2tb-294	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-960-048	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-960-049	Ổ cứng SSD 960GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	960.20GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-103	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-104	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-051	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-052	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-053	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-054	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-055	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
hdd-4tb-056	Ổ cứng HDD 4TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	4.0TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-105	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u36	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-106	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u39	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
ssd-240-107	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u41	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d12_hosts.txt	\N	{}	2026-09-15 06:25:55.715072+00	2026-09-15 06:25:55.715072+00	import	\N	f	f	\N
cap-10-0077	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	345	{}	2026-09-17 03:40:34.743214+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0078	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	346	{}	2026-09-17 03:40:34.805342+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0079	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	347	{}	2026-09-17 03:40:34.875683+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0080	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	348	{}	2026-09-17 03:40:34.940368+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0081	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	349	{}	2026-09-17 03:40:35.010812+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0082	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	350	{}	2026-09-17 03:40:35.092573+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0083	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	351	{}	2026-09-17 03:40:35.159969+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0084	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	352	{}	2026-09-17 03:40:35.225101+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0085	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	353	{}	2026-09-17 03:40:35.292307+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0086	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	354	{}	2026-09-17 03:40:35.358055+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0087	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	355	{}	2026-09-17 03:40:35.417334+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0088	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	356	{}	2026-09-17 03:40:35.483807+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0089	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	357	{}	2026-09-17 03:40:35.566702+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0090	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	358	{}	2026-09-17 03:40:35.645286+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0091	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	359	{}	2026-09-17 03:40:35.750017+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0092	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	360	{}	2026-09-17 03:40:35.834577+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0093	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	361	{}	2026-09-17 03:40:35.914882+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0094	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	362	{}	2026-09-17 03:40:36.006025+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-das-001	cáp DAS	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	363	{}	2026-09-17 03:40:37.754088+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-das-002	cáp DAS	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	364	{}	2026-09-17 03:40:37.832375+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-das-003	cáp DAS	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	365	{}	2026-09-17 03:40:37.905871+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-das-004	cáp DAS	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	366	{}	2026-09-17 03:40:37.986894+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-das-005	cáp DAS	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	367	{}	2026-09-17 03:40:38.059612+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-das-006	cáp DAS	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	368	{}	2026-09-17 03:40:38.137107+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-das-007	cáp DAS	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	369	{}	2026-09-17 03:40:38.216947+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-das-008	cáp DAS	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	370	{}	2026-09-17 03:40:38.297028+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-das-010	cáp DAS	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	372	{}	2026-09-17 03:40:38.506084+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-das-011	cáp DAS	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	373	{}	2026-09-17 03:40:38.598073+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-d12-u34	OPS - COMPUTE	server	\N	10.10.70.24	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	\N	\N	Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz · RAM 251.8 GiB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	odsvps05 · Supermicro Node 2U	netbox_devices (1).csv	11	{}	2026-09-15 07:48:31.451239+00	2026-09-15 03:25:35.015644+00	import	34	f	f	\N
ssd-240-074	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-075	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-149	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-150	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-151	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-152	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-153	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-154	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-155	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-156	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-157	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-158	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-159	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-160	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	5	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-076	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-077	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-161	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-162	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-163	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-164	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-165	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-166	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-167	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-168	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-169	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-170	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-171	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-172	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	6	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-078	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-079	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-173	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
cap-das-012	cáp DAS	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	374	{}	2026-09-17 03:40:38.706787+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
das-acc-002	đầu chuyển DAS	adapter	component	\N	đầu chuyển DAS	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	378	{unmapped_ip_or_type}	2026-09-17 03:40:39.630626+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
ssd-2tb-174	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-175	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-176	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-177	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-178	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-179	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-180	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-181	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-182	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-183	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-184	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	7	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-080	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-081	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-185	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-186	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-187	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-188	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-189	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-190	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-191	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-192	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-193	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-194	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-195	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-196	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	8	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-197	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-198	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-199	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-200	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-201	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-113	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-114	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-115	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-116	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-117	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-118	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-119	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-120	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-121	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-122	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-123	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-124	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-480-015	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-480-016	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u36	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	2	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-070	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-071	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-125	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-126	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-127	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-128	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-129	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-130	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-131	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-132	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-133	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-134	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-135	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-136	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	3	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-072	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-073	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-137	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-138	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-139	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-140	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-141	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-142	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-143	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-144	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-145	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-146	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-147	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-148	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	4	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-202	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-203	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-204	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-205	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-206	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-207	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-208	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-480-017	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-480-018	Ổ cứng SSD 480GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u34	\N	480.10GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	9	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-082	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-083	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-209	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-210	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-211	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-212	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-213	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-214	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-215	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-216	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-217	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-218	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-219	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-220	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	10	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-084	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-085	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-221	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-222	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-223	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-224	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-225	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-226	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-227	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-228	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-229	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-230	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-231	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-232	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	11	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
cap-10-0057	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	325	{}	2026-09-17 03:40:33.291805+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
ssd-240-086	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-087	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-233	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-234	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-235	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-236	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-237	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-238	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-239	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-240	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-241	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-242	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-243	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-244	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	12	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-088	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-089	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-245	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-246	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-247	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-248	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-249	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-250	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-251	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-252	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-253	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-254	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-255	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-256	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	13	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-090	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-240-091	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-257	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-258	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-259	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-260	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-261	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-262	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
cap-10-0058	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	326	{}	2026-09-17 03:40:33.358064+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
ssd-2tb-263	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-264	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-265	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-266	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-267	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
ssd-2tb-268	Ổ cứng SSD 1.9TB	disk	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	1.9TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_2556aad7-0310-41b3-a420-bb4df8b7da7c.csv	14	{}	2026-09-15 04:33:05.588812+00	2026-09-15 04:33:05.588812+00	import	\N	f	f	\N
cab-10g-029	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	sw-j6-12	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-005	Cáp 20Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	sw-j6-12	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
card-1-2-003	card 1Gpbs 2port	nic	component	\N	card mạng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	384	{}	2026-09-17 03:40:39.03107+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
card-10-2-001	card 10Gbps 2port	nic	component	\N	card mạng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	385	{}	2026-09-17 03:40:39.104418+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
card-10-2-002	card 10Gbps 2port	nic	component	\N	card mạng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	386	{}	2026-09-17 03:40:39.197271+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
card-10-2-003	card 10Gbps 2port	nic	component	\N	card mạng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	387	{}	2026-09-17 03:40:39.285777+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
das-acc-003	đầu chuyển DAS	adapter	component	\N	đầu chuyển DAS	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	379	{unmapped_ip_or_type}	2026-09-17 03:40:39.711247+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
das-acc-004	đầu chuyển DAS	adapter	component	\N	đầu chuyển DAS	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	380	{unmapped_ip_or_type}	2026-09-17 03:40:39.799718+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
das-acc-005	đầu chuyển DAS	adapter	component	\N	đầu chuyển DAS	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	381	{unmapped_ip_or_type}	2026-09-17 03:40:39.870682+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
hdd-4tb-0017	HDD SAS 4TB	disk	component	\N	hdd	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	404	{}	2026-09-17 03:40:40.631189+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
hdd-4tb-0018	HDD SAS 4TB	disk	component	\N	hdd	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	405	{}	2026-09-17 03:40:40.742132+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
hdd-4tb-0019	HDD SAS 4TB	disk	component	\N	hdd	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	406	{}	2026-09-17 03:40:40.851057+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
hdd-4tb-0020	HDD SAS 4TB	disk	component	\N	hdd	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	407	{}	2026-09-17 03:40:40.946054+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
hdd-4tb-0021	HDD SAS 4TB	disk	component	\N	hdd	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	408	{}	2026-09-17 03:40:41.02146+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
hdd-4tb-0030	HDD SAS 4TB	disk	component	\N	hdd	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	417	{}	2026-09-17 03:40:41.08747+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
hdd-4tb-0031	HDD SAS 4TB	disk	component	\N	hdd	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	418	{}	2026-09-17 03:40:41.150901+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
hdd-4tb-0033	HDD SAS 4TB	disk	component	\N	hdd	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	420	{}	2026-09-17 03:40:41.218502+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
hdd-4tb-0034	HDD SAS 4TB	disk	component	\N	hdd	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	broken	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	421	{}	2026-09-17 03:40:41.293238+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
module-10-001	module quang 10Gbps cisco	optical_module	component	\N	module	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	424	{}	2026-09-17 03:40:41.362992+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
module-10-003	module quang 10Gbps cisco	optical_module	component	\N	module	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	426	{}	2026-09-17 03:40:41.533378+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
module-10-004	module quang 10Gbps cisco	optical_module	component	\N	module	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	427	{}	2026-09-17 03:40:41.615404+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
module-10-005	module quang 10Gbps cisco	optical_module	component	\N	module	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	428	{}	2026-09-17 03:40:41.694348+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
module-10-006	module quang 10Gbps cisco	optical_module	component	\N	module	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	429	{}	2026-09-17 03:40:41.765136+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
module-10-007	module quang 10Gbps cisco	optical_module	component	\N	module	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	430	{}	2026-09-17 03:40:41.841194+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
module-10-008	module quang 10Gbps cisco	optical_module	component	\N	module	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	431	{}	2026-09-17 03:40:41.907399+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
module-10-009	module quang 10Gbps cisco	optical_module	component	\N	module	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	432	{}	2026-09-17 03:40:41.972548+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
card-raid-001	card RAID	raid_card	component	\N	card RAID	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	505	{unmapped_ip_or_type}	2026-09-17 03:40:39.363413+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
card-raid-002	card RAID external	unknown	component	\N	card RAID external	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	504	{unmapped_ip_or_type}	2026-09-17 03:40:39.435327+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cab-10g-053	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u08	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-054	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u08	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-055	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u10	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-056	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u10	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-057	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u13	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-058	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u13	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-059	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u15	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-060	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u15	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-061	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u18	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-062	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u18	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-063	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u20	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-064	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u20	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-065	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u23	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-066	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u23	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-067	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u25	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-068	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u25	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-069	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u28	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-070	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u28	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-071	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u30	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-072	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u30	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-073	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u33	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-074	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u33	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-075	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u35	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-076	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u35	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-077	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u38	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-078	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u38	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-079	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u40	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-080	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u40	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-081	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	sw-j5-u39	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-009	Cáp 20Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	sw-j5-u39	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-082	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	sw-j5-u40	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-010	Cáp 20Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	sw-j5-u40	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-083	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-084	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u06	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-085	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-086	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u09	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-087	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-088	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u11	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-089	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-090	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u14	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-091	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-092	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u16	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-093	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-094	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u19	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-095	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-096	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u21	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-097	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-098	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u24	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-099	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-100	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u26	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-101	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-102	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u29	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-103	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-104	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	19	svr-j5-u31	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-110	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	sw-j6-u44	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-012	Cáp 20Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	sw-j6-u44	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-111	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u04	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-112	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u04	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-113	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u07	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-114	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u07	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-115	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u09	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-116	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u09	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-117	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u18	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-118	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u18	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-119	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u20	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-120	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u20	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-121	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u23	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-122	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u23	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-123	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u25	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-001	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	sw-aq53-u32	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-001	Cáp 20Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	sw-aq53-u32	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-002	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	sw-aq53-u33	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-002	Cáp 20Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	sw-aq53-u33	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-003	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u17	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-004	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u17	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-005	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u20	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-006	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u20	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-007	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u22	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-008	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u22	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-009	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u24	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-010	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u24	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-011	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u26	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-012	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u26	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-013	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u30	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-014	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	21	svr-aq53-u30	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-015	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	sw-bd51-u22	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-003	Cáp 20Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	sw-bd51-u22	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-016	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	sw-bd51-u23	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-004	Cáp 20Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	sw-bd51-u23	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-017	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u13	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-018	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u13	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-019	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u16	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-020	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u16	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-021	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u19	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-022	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u19	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-023	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u35	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-024	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u35	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-025	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u37	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-026	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u37	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-027	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u39	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-028	Cáp 10Gbps	cable	\N	\N	\N	\N	VNPT Tân Thuận	VNPT Tân Thuận	2594	14	23	svr-bd51-u39	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-031	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-032	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u24	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-033	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-034	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u26	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-035	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-036	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u29	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-037	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-038	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u31	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-039	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-040	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u34	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-041	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u36	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-042	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u36	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-043	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u39	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-044	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u39	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-045	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u41	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-046	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	svr-d12-u41	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-047	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	sw-j4-u43	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-007	Cáp 20Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	sw-j4-u43	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-048	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	sw-j4-u44	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-008	Cáp 20Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	sw-j4-u44	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-049	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u03	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-030	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	sw-j6-13	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-006	Cáp 20Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	11	14	sw-j6-13	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-050	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u03	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-051	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u05	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-052	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	18	svr-j4-u05	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-124	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u25	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-125	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u28	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-126	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u28	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-127	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u30	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-128	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u30	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-129	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u33	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-130	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u33	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-131	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u35	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-132	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u35	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-133	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u38	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-134	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u38	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-135	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u40	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-136	Cáp 10Gbps	cable	\N	\N	\N	\N	ODS	ODS	2595	13	20	svr-j6-u40	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-137	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	sw-p07-u41	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-013	Cáp 20Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	sw-p07-u41	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-138	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	sw-p07-u42	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-20g-014	Cáp 20Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	sw-p07-u42	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 20Gbps của switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-139	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-140	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-141	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-142	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-143	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-144	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-145	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-146	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-147	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-148	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-149	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-150	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-151	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
cab-10g-152	Cáp 10Gbps	cable	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	\N	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cáp 10Gbps nối server với switch storage	Sinh theo quy tắc: rack có 2 switch storage	\N	{}	2026-09-15 06:10:10.039338+00	2026-09-15 06:10:10.039338+00	import	\N	f	f	\N
ssd-8tb-002	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-003	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-004	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-005	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-006	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-007	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-008	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-009	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-010	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-011	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-012	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-013	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-014	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-001	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-002	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u23	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	2	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-015	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
cap-10-099	Module quang AOC SFP+ to SFP+ 10G dài 10M	cable	component	\N	cáp	POC Openstack	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	2026-10-03	\N	\N	\N	\N	\N	\N	\N	\N	cáp quang 10Gbps 10m	TỔNG HỢP	790	{location_from_last_transfer,status_from_last_transfer}	2026-09-17 03:40:36.74329+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-100	Module quang AOC SFP+ to SFP+ 10G dài 10M	cable	component	\N	cáp	POC Openstack	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	2026-10-03	\N	\N	\N	\N	\N	\N	\N	\N	cáp quang 10Gbps 10m	TỔNG HỢP	791	{location_from_last_transfer,status_from_last_transfer}	2026-09-17 03:40:36.813027+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-101	Module quang AOC SFP+ to SFP+ 10G dài 10M	cable	component	\N	cáp	POC Openstack	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	2026-10-03	\N	\N	\N	\N	\N	\N	\N	\N	cáp quang 10Gbps 10m	TỔNG HỢP	792	{location_from_last_transfer,status_from_last_transfer}	2026-09-17 03:40:36.893514+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-102	Module quang AOC SFP+ to SFP+ 10G dài 10M	cable	component	\N	cáp	POC Openstack	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	2026-10-03	\N	\N	\N	\N	\N	\N	\N	\N	cáp quang 10Gbps 10m	TỔNG HỢP	793	{location_from_last_transfer,status_from_last_transfer}	2026-09-17 03:40:36.977943+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-103	Module quang AOC SFP+ to SFP+ 10G dài 10M	cable	component	\N	cáp	POC Openstack	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	2026-10-03	\N	\N	\N	\N	\N	\N	\N	\N	cáp quang 10Gbps 10m	TỔNG HỢP	794	{location_from_last_transfer,status_from_last_transfer}	2026-09-17 03:40:37.063984+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-104	Module quang AOC SFP+ to SFP+ 10G dài 10M	cable	component	\N	cáp	POC Openstack	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	2026-10-03	\N	\N	\N	\N	\N	\N	\N	\N	cáp quang 10Gbps 10m	TỔNG HỢP	795	{location_from_last_transfer,status_from_last_transfer}	2026-09-17 03:40:37.137671+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-107	Module quang AOC SFP+ to SFP+ 10G dài 10M	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	cáp quang 10Gbps 10m	TỔNG HỢP	809	{}	2026-09-17 03:40:37.212586+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-108	Module quang AOC SFP+ to SFP+ 10G dài 10M	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	cáp quang 10Gbps 10m	TỔNG HỢP	810	{}	2026-09-17 03:40:37.282485+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-109	Module quang AOC SFP+ to SFP+ 10G dài 10M	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	cáp quang 10Gbps 10m	TỔNG HỢP	811	{}	2026-09-17 03:40:37.346189+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-110	Module quang AOC SFP+ to SFP+ 10G dài 10M	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	cáp quang 10Gbps 10m	TỔNG HỢP	812	{}	2026-09-17 03:40:37.410952+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
ssd-8tb-016	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-017	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-018	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-019	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-020	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-021	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-022	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-023	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-024	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-025	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-026	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-027	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-028	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-003	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-004	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u26	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	3	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-029	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-030	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-031	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-032	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-033	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-034	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-035	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-036	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-037	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-038	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-039	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-040	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-041	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-042	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-043	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-005	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-006	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u28	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	4	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-044	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-045	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-046	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-047	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-048	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-049	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-050	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-051	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-052	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-053	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-054	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-055	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-056	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-057	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-058	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-007	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-008	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u31	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	5	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-059	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-060	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-061	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-062	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-063	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-064	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-065	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-066	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-067	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-068	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-069	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-070	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-071	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-072	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-073	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-009	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-010	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u33	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	6	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-074	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-075	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-076	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-077	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-078	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-079	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-080	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-081	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-082	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-083	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-084	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-085	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-086	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-087	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-088	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-011	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-012	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u36	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	7	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-089	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-090	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-091	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-092	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-093	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-094	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-095	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-096	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-097	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-098	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-099	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-100	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-101	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-102	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-8tb-103	Ổ cứng SSD 7.7TB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	7.7TB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-013	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
ssd-240-014	Ổ cứng SSD 240GB	disk	\N	\N	\N	\N	CMC Tân Thuận	CMC Tân Thuận	2592	12	15	svr-p07-u38	\N	240.06GB	\N	in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	host_772d6f84-1096-406d-b70b-277c783585b7.csv	8	{}	2026-09-17 03:18:40.804171+00	2026-09-15 04:03:04.375326+00	import	\N	f	f	\N
cap-10-0064	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	332	{}	2026-09-17 03:40:33.799661+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0065	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	333	{}	2026-09-17 03:40:33.879305+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0066	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	334	{}	2026-09-17 03:40:33.956042+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0071	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	339	{}	2026-09-17 03:40:34.314302+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0072	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	340	{}	2026-09-17 03:40:34.381046+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0073	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	341	{}	2026-09-17 03:40:34.456277+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0074	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	342	{}	2026-09-17 03:40:34.533034+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0075	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	343	{}	2026-09-17 03:40:34.603941+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0076	cáp 10Gbps	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	344	{}	2026-09-17 03:40:34.674869+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0095	cáp quang 10Gbps 10m	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	375	{}	2026-09-17 03:40:36.100343+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0096	cáp quang 10Gbps 10m	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	376	{}	2026-09-17 03:40:36.21793+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0125	Cáp 10Gb	cable	component	\N	cáp	Cluster9	\N	\N	\N	\N	\N	\N	\N	\N	\N	not_in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	536	{parent_reference_unresolved,location_from_last_transfer}	2026-09-17 03:40:36.311146+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0149	Cáp 10Gb	cable	component	\N	cáp	ClusterX1	\N	\N	\N	\N	\N	\N	\N	\N	\N	not_in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	562	{parent_reference_unresolved,location_from_last_transfer}	2026-09-17 03:40:36.414105+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-0150	Cáp 10Gb	cable	component	\N	cáp	ClusterX1	\N	\N	\N	\N	\N	\N	\N	\N	\N	not_in_use	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	563	{parent_reference_unresolved,location_from_last_transfer}	2026-09-17 03:40:36.523115+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-097	Module quang AOC SFP+ to SFP+ 10G dài 10M	cable	component	\N	cáp	POC Openstack	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	2026-10-03	\N	\N	\N	\N	\N	\N	\N	\N	cáp quang 10Gbps 10m	TỔNG HỢP	788	{location_from_last_transfer,status_from_last_transfer}	2026-09-17 03:40:36.606975+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-10-098	Module quang AOC SFP+ to SFP+ 10G dài 10M	cable	component	\N	cáp	POC Openstack	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	2026-10-03	\N	\N	\N	\N	\N	\N	\N	\N	cáp quang 10Gbps 10m	TỔNG HỢP	789	{location_from_last_transfer,status_from_last_transfer}	2026-09-17 03:40:36.67603+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
cap-das-009	cáp DAS	cable	component	\N	cáp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	371	{}	2026-09-17 03:40:38.406435+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
card-1-2-001	card 1Gpbs 2port	nic	component	\N	card mạng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	382	{}	2026-09-17 03:40:38.8198+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
card-1-2-002	card 1Gpbs 2port	nic	component	\N	card mạng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	383	{}	2026-09-17 03:40:38.935486+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
das-acc-001	đầu chuyển DAS	adapter	component	\N	đầu chuyển DAS	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	377	{unmapped_ip_or_type}	2026-09-17 03:40:39.533023+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
das-kho-001	DAS-KHO-001	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	251	{}	2026-09-17 03:40:39.947144+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
das-kho-002	DAS-KHO-002	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	252	{}	2026-09-17 03:40:40.032659+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
module-10-002	module quang 10Gbps cisco	optical_module	component	\N	module	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	in_stock	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	425	{}	2026-09-17 03:40:41.4487+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-009	SVR-KHO-009	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	218	{}	2026-09-17 03:40:43.265866+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-010	SVR-KHO-010	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	219	{}	2026-09-17 03:40:43.346707+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-020	SVR-KHO-020	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	229	{}	2026-09-17 03:40:44.062276+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-021	SVR-KHO-021	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	230	{}	2026-09-17 03:40:44.127982+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-022	SVR-KHO-022	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	231	{}	2026-09-17 03:40:44.194045+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-023	SVR-KHO-023	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	232	{}	2026-09-17 03:40:44.266531+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-024	SVR-KHO-024	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	233	{}	2026-09-17 03:40:44.345914+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-025	SVR-KHO-025	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	234	{}	2026-09-17 03:40:44.420477+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-026	SVR-KHO-026	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	235	{}	2026-09-17 03:40:44.49106+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
svr-kho-027	SVR-KHO-027	server	server	\N	server	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	retired	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	TỔNG HỢP	236	{}	2026-09-17 03:40:44.564452+00	2026-09-15 10:05:40.215089+00	import	\N	t	f	\N
\.


--
-- Data for Name: asset_event; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.asset_event (id, asset_id, event_sequence, event_type, event_date, location, usage_object, notes, declared_transition_count, source_column, source_row, review_flags, created_at, updated_at, origin) FROM stdin;
1479	svr-j3-u36	1	transfer	2026-10-12	CMC Tân Thuận · Room 1 · rack D12 U21	\N	\N	\N	\N	\N	{}	2026-10-12 07:09:13.870417+00	2026-10-12 07:09:13.870417+00	manual
1480	hdd-4tb-001	1	transfer	2026-10-12	CMC Tân Thuận · Room 1 · rack D12 U21	\N	\N	\N	\N	\N	{}	2026-10-12 07:09:13.870417+00	2026-10-12 07:09:13.870417+00	manual
1481	hdd-4tb-002	1	transfer	2026-10-12	CMC Tân Thuận · Room 1 · rack D12 U21	\N	\N	\N	\N	\N	{}	2026-10-12 07:09:13.870417+00	2026-10-12 07:09:13.870417+00	manual
1482	hdd-4tb-003	1	transfer	2026-10-12	CMC Tân Thuận · Room 1 · rack D12 U21	\N	\N	\N	\N	\N	{}	2026-10-12 07:09:13.870417+00	2026-10-12 07:09:13.870417+00	manual
1483	hdd-4tb-004	1	transfer	2026-10-12	CMC Tân Thuận · Room 1 · rack D12 U21	\N	\N	\N	\N	\N	{}	2026-10-12 07:09:13.870417+00	2026-10-12 07:09:13.870417+00	manual
1484	raid-240-002	1	transfer	2026-10-12	CMC Tân Thuận · Room 1 · rack D12 U21	\N	\N	\N	\N	\N	{}	2026-10-12 07:09:13.870417+00	2026-10-12 07:09:13.870417+00	manual
1485	ssd-480-003	1	transfer	2026-10-12	CMC Tân Thuận · Room 1 · rack D12 U21	\N	\N	\N	\N	\N	{}	2026-10-12 07:09:13.870417+00	2026-10-12 07:09:13.870417+00	manual
1486	ssd-480-004	1	transfer	2026-10-12	CMC Tân Thuận · Room 1 · rack D12 U21	\N	\N	\N	\N	\N	{}	2026-10-12 07:09:13.870417+00	2026-10-12 07:09:13.870417+00	manual
\.


--
-- Data for Name: asset_type; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.asset_type (code, label, note, sort_order) FROM stdin;
switch	Switch	\N	2
firewall	Firewall	\N	3
network_or_host	Thiết bị mạng / Host	\N	4
hsm	HSM	\N	5
disk	Ổ cứng	\N	6
ram	RAM	\N	7
cpu	CPU	\N	8
raid_card	Card RAID	\N	9
nic	Card mạng	\N	10
optical_module	Module quang	\N	11
power_supply	Bộ nguồn	\N	12
adapter	Adapter	\N	13
cable	Cáp	\N	14
raid_cable	Cáp RAID	\N	15
unknown	Chưa xác định	\N	99
server	Server	\N	1
storage	Thiết bị lưu trữ	NAS, DAS — tủ đĩa gắn ngoài	100
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.audit_log (id, at, username, action, entity, entity_id, changes, note) FROM stdin;
1	2026-09-17 04:08:19.720538+00	admin	them	asset	nk-thu-01	{"origin": {"cu": null, "moi": "manual"}, "asset_id": {"cu": null, "moi": "nk-thu-01"}, "asset_name": {"cu": null, "moi": "Máy thử nhật ký"}, "asset_type": {"cu": null, "moi": "server"}, "code_pending": {"cu": null, "moi": "False"}, "usage_status": {"cu": null, "moi": "in_use"}}	\N
2	2026-09-17 04:08:19.816033+00	admin	sua	asset	nk-thu-01	{"asset_name": {"cu": "Máy thử nhật ký", "moi": "Máy thử ĐÃ SỬA"}, "usage_status": {"cu": "in_use", "moi": "broken"}}	\N
3	2026-09-17 04:08:19.889289+00	admin	them	cluster	CumThuNhatKy	\N	\N
4	2026-09-17 04:08:19.94759+00	admin	xoa	cluster	CumThuNhatKy	\N	\N
5	2026-09-17 04:08:20.015213+00	admin	them	asset_type	loai_thu	{"label": {"cu": null, "moi": "Loại thử"}}	\N
6	2026-09-17 04:08:20.077909+00	admin	xoa	asset_type	loai_thu	\N	\N
7	2026-09-17 04:08:20.1458+00	admin	xoa	asset	nk-thu-01	{"asset_id": {"cu": "nk-thu-01", "moi": null}, "asset_name": {"cu": "Máy thử ĐÃ SỬA", "moi": null}, "asset_type": {"cu": "server", "moi": null}, "datacenter": {"cu": null, "moi": null}, "usage_status": {"cu": "broken", "moi": null}, "parent_asset_id": {"cu": null, "moi": null}}	\N
8	2026-09-17 04:19:23.023709+00	admin	them	user	kietoan	{"role": {"cu": null, "moi": "xem"}}	tạo tài khoản mới
9	2026-09-17 04:19:23.17333+00	admin	them	user	sa2	{"role": {"cu": null, "moi": "sua"}}	tạo tài khoản mới
10	2026-09-17 04:19:38.032543+00	sa2	them	asset	pq-thu	{"origin": {"cu": null, "moi": "manual"}, "asset_id": {"cu": null, "moi": "pq-thu"}, "asset_name": {"cu": null, "moi": "Thử quyền"}, "asset_type": {"cu": null, "moi": "server"}, "code_pending": {"cu": null, "moi": "False"}}	\N
11	2026-09-17 04:19:38.474499+00	admin	them	user	zzz	{"role": {"cu": null, "moi": "xem"}}	tạo tài khoản mới
12	2026-09-17 04:19:38.702433+00	admin	xoa	asset	pq-thu	{"asset_id": {"cu": "pq-thu", "moi": null}, "asset_name": {"cu": "Thử quyền", "moi": null}, "asset_type": {"cu": "server", "moi": null}, "datacenter": {"cu": null, "moi": null}, "usage_status": {"cu": null, "moi": null}, "parent_asset_id": {"cu": null, "moi": null}}	\N
13	2026-09-17 04:19:38.768063+00	admin	xoa	user	zzz	{"role": {"cu": "xem", "moi": null}}	xóa tài khoản
14	2026-09-17 04:24:47.387174+00	admin	xoa	user	kietoan	{"role": {"cu": "xem", "moi": null}}	xóa tài khoản
15	2026-09-17 04:24:47.46194+00	admin	xoa	user	sa2	{"role": {"cu": "sua", "moi": null}}	xóa tài khoản
16	2026-09-17 04:32:59.915082+00	admin	sao_luu	data	\N	\N	sao lưu tay: atlas-20260917-043259.sql.gz
17	2026-09-17 04:33:00.27277+00	admin	sua	backup	\N	{"keep": {"cu": "14", "moi": "7"}, "minute": {"cu": "0", "moi": "30"}, "enabled": {"cu": "False", "moi": "True"}}	đổi cấu hình sao lưu
18	2026-09-17 04:33:30.891459+00	admin	sua	backup	\N	{"keep": {"cu": "7", "moi": "2"}}	đổi cấu hình sao lưu
19	2026-09-17 04:33:30.962409+00	admin	sao_luu	data	\N	\N	sao lưu tay: atlas-20260917-043330.sql.gz
20	2026-09-17 04:33:32.498814+00	admin	sao_luu	data	\N	\N	sao lưu tay: atlas-20260917-043332.sql.gz
21	2026-09-17 04:33:34.049997+00	admin	sao_luu	data	\N	\N	sao lưu tay: atlas-20260917-043334.sql.gz
22	2026-09-17 04:36:27.879491+00	admin	sua	backup	\N	{"keep": {"cu": "2", "moi": "14"}, "minute": {"cu": "30", "moi": "0"}}	đổi cấu hình sao lưu
23	2026-09-17 04:49:31.587912+00	admin	sao_luu	data	\N	\N	sao lưu tay: atlas-20260917-044931.sql.gz
24	2026-09-17 06:36:21.239626+00	admin	sao_luu	data	\N	\N	sao lưu tay: atlas-20260917-063621.sql.gz
25	2026-09-17 06:39:14.272392+00	admin	sao_luu	data	\N	\N	sao lưu tay: mgmt-device-20260917-063914.sql.gz
26	2026-09-18 02:00:42.097145+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260918-020042.sql.gz
27	2026-09-18 03:03:59.536602+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260918-030359.sql.gz
28	2026-09-19 02:00:37.382243+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260919-020037.sql.gz
29	2026-09-20 02:00:13.808971+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260920-020013.sql.gz
30	2026-09-21 02:00:53.507726+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260921-020053.sql.gz
31	2026-09-22 02:00:27.85755+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260922-020027.sql.gz
32	2026-09-23 02:00:07.530082+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260923-020007.sql.gz
33	2026-09-24 02:00:47.732617+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260924-020047.sql.gz
34	2026-09-25 02:00:27.980825+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260925-020027.sql.gz
35	2026-09-26 02:00:07.651356+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260926-020007.sql.gz
36	2026-09-27 02:00:47.847009+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260927-020047.sql.gz
37	2026-09-28 02:00:27.823128+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260928-020027.sql.gz
38	2026-09-29 02:00:07.609072+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260929-020007.sql.gz
39	2026-09-30 02:00:41.386102+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20260930-020041.sql.gz
40	2026-10-01 02:00:20.444029+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20261001-020020.sql.gz
41	2026-10-02 02:00:59.38181+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20261002-020059.sql.gz
42	2026-10-03 02:00:37.992476+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20261003-020037.sql.gz
43	2026-10-04 02:00:17.169884+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20261004-020017.sql.gz
44	2026-10-05 02:00:56.112034+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20261005-020056.sql.gz
45	2026-10-06 02:00:34.804563+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20261006-020034.sql.gz
46	2026-10-07 02:00:13.786041+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20261007-020013.sql.gz
47	2026-10-08 02:00:52.781648+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20261008-020052.sql.gz
48	2026-10-09 02:00:31.707239+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20261009-020031.sql.gz
49	2026-10-10 02:00:10.422056+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20261010-020010.sql.gz
50	2026-10-11 02:00:48.797554+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20261011-020048.sql.gz
51	2026-10-12 02:00:27.451129+00	hệ thống	sao_luu	data	\N	\N	sao lưu tự động: mgmt-device-20261012-020027.sql.gz
\.


--
-- Data for Name: backup_config; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.backup_config (id, enabled, hour, minute, keep, last_run_at, last_status, updated_at) FROM stdin;
1	t	2	0	14	2026-10-12 02:00:27.451129+00	tự động · mgmt-device-20261012-020027.sql.gz	2026-09-17 04:36:27.879491+00
\.


--
-- Data for Name: cluster; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.cluster (name, note) FROM stdin;
HOSTING	\N
CLOUDSERVER	\N
EMAIL	\N
OPENSTACK	\N
backup	\N
monitor	\N
ClusterX1	\N
Cluster9	\N
POC Openstack	\N
CMC1	\N
MBIN & MBCA	\N
Cluster8	\N
MBO	\N
VNPT1	\N
Sangfor tạm	\N
\.


--
-- Data for Name: export_template; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.export_template (id, name, note, file_name, sheet_name, header_rows, scope, maps, col_defs, created_at, updated_at) FROM stdin;
4	Kiểm kê thiết bị SA → ERP	Dựng theo file NB-HR-Kiem ke thiet bi SA. Dòng tiêu đề thứ HAI là đường dẫn trường của ERP — sai một chữ là ERP từ chối cả file, đừng sửa nếu không có yêu cầu từ bên nhận. Ba chỗ còn CHỜ CHỐT: (1) cột NƠI BẢO QUẢN trong file gốc ghép 5 mảnh site-cụm-loại-nơi gắn-đối tượng sử dụng, app chưa có 'đối tượng sử dụng' theo từng tài sản nên tạm ghép 3 mảnh; (2) trạng thái hỏng và suy giảm đang xếp tạm; (3) bốn cột THƯƠNG HIỆU, NHÂN VIÊN, NHÀ CUNG CẤP, NGÀY HẾT BẢO HÀNH để trống đúng như file gốc dù app có sẵn dữ liệu.	Kiem ke thiet bi SA - ERP.xlsx	Dữ liệu làm sạch sẽ up lên ERP	2	{}	{"ten_erp": {"*": "", "hsm/hsm": "HSM", "disk/hdd": "HDD", "disk/ssd": "SSD", "nic/card": "Card", "cable/cab": "Cáp", "cable/cap": "Cáp", "disk/CHUA": "", "disk/raid": "SSD", "switch/sw": "Switch", "server/das": "DAS", "server/svr": "Máy chủ", "adapter/das": "Card", "firewall/fw": "Firewall", "storage/sto": "NAS", "unknown/card": "Card", "raid_card/card": "Card", "network_or_host/svr": "Máy chủ", "optical_module/module": "Module"}, "trang_thai_erp": {"*": "", "broken": "Chờ hủy/thanh lý", "in_use": "Đang sử dụng", "retired": "Đã thanh lý", "degraded": "Đang sử dụng", "in_stock": "Sẵn sàng", "not_in_use": "Sẵn sàng", "pending_disposal": "Chờ hủy/thanh lý", "in_use_needs_replacement": "Đang sử dụng"}}	[{"mau": "Thiết Bị System Admin", "bang": "", "kieu": "chu", "header1": "PHÂN LOẠI TÀI SẢN", "header2": "Equipment/Equipment Category/Category Name"}, {"mau": "$asset_type/$ma_tien_to", "bang": "ten_erp", "kieu": "chu", "header1": "TÊN TÀI SẢN", "header2": "Equipment/Name"}, {"mau": "$description", "bang": "", "kieu": "chu", "header1": "MÔ TẢ TÀI SẢN", "header2": "Equipment/Description"}, {"mau": "$ma_hien_thi", "bang": "", "kieu": "chu", "header1": "MÃ TÀI SẢN/SỐ SERI", "header2": "Equipment/Product Information/Serial Number"}, {"mau": "$purchase_invoice", "bang": "", "kieu": "chu", "header1": "Mã tài sản/ phân bổ - FI", "header2": ""}, {"mau": "", "bang": "", "kieu": "chu", "header1": "THƯƠNG HIỆU", "header2": "Equipment/Product Information/Model"}, {"mau": "", "bang": "", "kieu": "chu", "header1": "TÌNH TRẠNG PHÂN BỔ/KHẤU HAO", "header2": "Allocation Status (Việt)"}, {"mau": "", "bang": "", "kieu": "chu", "header1": "TÌNH TRẠNG PHÂN BỔ/KHẤU HAO", "header2": "Allocation Status (Anh)"}, {"mau": "${usage_status|trang_thai_erp}", "bang": "", "kieu": "chu", "header1": "TRẠNG THÁI SỬ DỤNG", "header2": "Equipment/Equipment state (Việt)"}, {"mau": "", "bang": "", "kieu": "chu", "header1": "TRẠNG THÁI SỬ DỤNG", "header2": "Equipment/Equipment state (Anh)"}, {"mau": "", "bang": "", "kieu": "chu", "header1": "Used by", "header2": "Used by"}, {"mau": "System Admin", "bang": "", "kieu": "chu", "header1": "PHÒNG BAN", "header2": "Equipment/Used by/Department"}, {"mau": "", "bang": "", "kieu": "chu", "header1": "NHÂN VIÊN/PHÒNG BAN SỬ DỤNG", "header2": "Equipment/Used by/Employee"}, {"mau": "$noi_luu-$cluster-$loai_nhan", "bang": "", "kieu": "chu", "header1": "NƠI BẢO QUẢN", "header2": "Equipment/Used in location"}, {"mau": "$handover_date", "bang": "", "kieu": "ngay", "header1": "NGÀY NHẬP KHO", "header2": "Equipment/Product Information/Effective Date"}, {"mau": "$purchase_price_vnd", "bang": "", "kieu": "so", "header1": "GIÁ MUA (GỒM VAT)", "header2": "Equipment/Product Information/Cost"}, {"mau": "", "bang": "", "kieu": "chu", "header1": "NHÀ CUNG CẤP", "header2": "Equipment/Product Information/Vendor"}, {"mau": "", "bang": "", "kieu": "ngay", "header1": "NGÀY HẾT BẢO HÀNH", "header2": "Equipment/Product Information/Warranty Expiration Date"}, {"mau": "", "bang": "", "kieu": "chu", "header1": "Số PO", "header2": "Equipment/Product Information/Vendor Reference"}]	2026-09-17 08:33:15.203045+00	2026-09-17 08:33:15.203045+00
5	Biên bản bàn giao thiết bị	Mẫu đọc bằng mắt: một dòng tiêu đề tiếng Việt, chỉ lấy thiết bị đang vận hành.	Bien ban ban giao thiet bi.xlsx	Bàn giao	1	{"in_store": "0"}	{}	[{"mau": "$stt", "bang": "", "kieu": "so", "header1": "STT", "header2": ""}, {"mau": "$ma_hien_thi", "bang": "", "kieu": "chu", "header1": "Mã tài sản", "header2": ""}, {"mau": "$asset_name", "bang": "", "kieu": "chu", "header1": "Tên thiết bị", "header2": ""}, {"mau": "$loai_nhan", "bang": "", "kieu": "chu", "header1": "Loại", "header2": ""}, {"mau": "$noi_luu", "bang": "", "kieu": "chu", "header1": "Site", "header2": ""}, {"mau": "$rack", "bang": "", "kieu": "chu", "header1": "Rack", "header2": ""}, {"mau": "$rack_unit", "bang": "", "kieu": "so", "header1": "Ô U", "header2": ""}, {"mau": "$cluster", "bang": "", "kieu": "chu", "header1": "Cụm", "header2": ""}, {"mau": "$trang_thai_nhan", "bang": "", "kieu": "chu", "header1": "Trạng thái", "header2": ""}, {"mau": "$serial", "bang": "", "kieu": "chu", "header1": "Số serial / license", "header2": ""}, {"mau": "$handover_date", "bang": "", "kieu": "ngay", "header1": "Ngày bàn giao", "header2": ""}]	2026-09-17 08:33:15.203045+00	2026-09-17 08:33:15.203045+00
6	Kiểm kê hàng trong kho	Chỉ tài sản đang trong kho. Dùng khi đối chiếu số lượng tồn với bộ phận khác.	Kiem ke hang trong kho.xlsx	Tồn kho	1	{"in_store": "1"}	{}	[{"mau": "$stt", "bang": "", "kieu": "so", "header1": "STT", "header2": ""}, {"mau": "$ma_hien_thi", "bang": "", "kieu": "chu", "header1": "Mã tài sản", "header2": ""}, {"mau": "$asset_name", "bang": "", "kieu": "chu", "header1": "Tên", "header2": ""}, {"mau": "$loai_nhan", "bang": "", "kieu": "chu", "header1": "Loại", "header2": ""}, {"mau": "$capacity", "bang": "", "kieu": "chu", "header1": "Dung lượng / cấu hình", "header2": ""}, {"mau": "$trang_thai_nhan", "bang": "", "kieu": "chu", "header1": "Trạng thái", "header2": ""}, {"mau": "$description", "bang": "", "kieu": "chu", "header1": "Mô tả", "header2": ""}]	2026-09-17 08:33:15.203045+00	2026-09-17 08:33:15.203045+00
\.


--
-- Data for Name: import_log; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.import_log (id, kind, file_name, file_type, rows_read, added, updated, skipped, username, created_at) FROM stdin;
8	assets	netbox_assets_import.csv	csv	154	154	0	0	admin	2026-09-15 03:25:35.015644+00
9	assets	p07_disks_import.csv	csv	117	117	0	0	admin	2026-09-15 04:03:04.375326+00
10	assets	aq_disks_import.csv	csv	55	55	0	0	admin	2026-09-15 04:16:52.497601+00
11	assets	j_disks_import.csv	csv	137	137	0	0	admin	2026-09-15 04:31:07.129724+00
12	assets	j6_disks_import.csv	csv	60	60	0	0	admin	2026-09-15 04:32:48.404488+00
13	assets	j5_disks_import.csv	csv	182	182	0	0	admin	2026-09-15 04:33:05.588812+00
14	assets	bd51_disks_import.csv	csv	43	43	0	0	admin	2026-09-15 04:40:42.097909+00
15	assets	j6_bosung.csv	csv	7	7	0	0	admin	2026-09-15 04:47:25.043196+00
16	assets	cables_import.csv	csv	166	166	0	0	admin	2026-09-15 06:10:10.039338+00
17	assets	d12_disks_import.csv	csv	71	71	0	0	admin	2026-09-15 06:25:55.715072+00
18	assets	kho_import.csv	csv	6	6	0	0	admin	2026-09-15 08:40:29.742804+00
19	assets	kho_import.csv	csv	6	0	6	0	admin	2026-09-15 08:41:07.996846+00
20	assets	kho_186.csv	csv	186	186	0	0	admin	2026-09-15 08:47:24.643333+00
21	assets	raid_cards.csv	csv	7	7	0	0	admin	2026-09-15 09:22:51.507266+00
22	assets	raid_cables.csv	csv	14	14	0	0	admin	2026-09-15 09:25:49.525615+00
23	assets	kho_con_lai.csv	csv	400	400	0	0	admin	2026-09-15 09:33:39.020622+00
24	assets	cmc1_ve_p07.csv	csv	28	0	28	0	admin	2026-09-15 09:35:59.508242+00
25	assets	ra_khoi_kho.csv	csv	370	0	370	0	admin	2026-09-15 09:46:34.410144+00
26	assets	kho_final.csv	csv	241	241	0	0	admin	2026-09-15 10:05:40.215089+00
27	assets	thu_dung_ma.csv	csv	1	0	0	1	admin	2026-09-17 03:17:52.753332+00
28	assets	thu_dung_ma.csv	csv	1	0	1	0	admin	2026-09-17 03:18:40.05004+00
29	assets	p07_disks_import.csv	csv	117	0	117	0	admin	2026-09-17 03:18:40.804171+00
30	assets	chua_gan_ma.csv	csv	54	54	0	0	admin	2026-09-17 03:42:28.389948+00
31	assets	thu_cum.csv	csv	2	2	0	0	admin	2026-09-17 03:53:13.737348+00
\.


--
-- Data for Name: placement; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.placement (id, asset_id, rack_id, start_u, size_u, from_date, to_date) FROM stdin;
\.


--
-- Data for Name: rack; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.rack (id, room_id, code, height_u, status) FROM stdin;
13	10	M08	42	Đang sử dụng
14	11	D12	48	Đang sử dụng
15	12	P07	48	Đang sử dụng
16	13	J2	48	Đang sử dụng
17	13	J3	48	Đang sử dụng
18	13	J4	48	Đang sử dụng
19	13	J5	48	Đang sử dụng
20	13	J6	48	Đang sử dụng
21	14	AQ53	42	Đang sử dụng
22	14	AQ54	42	Đang sử dụng
23	14	BD51	42	Đang sử dụng
\.


--
-- Data for Name: room; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.room (id, site_id, code, name) FROM stdin;
10	2593	Room 1	\N
11	2592	Room 1	\N
12	2592	Room 2	\N
13	2595	Room 1	\N
14	2594	Room 1	\N
\.


--
-- Data for Name: site; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.site (id, name, kind, status) FROM stdin;
2592	CMC Tân Thuận	datacenter	Đang sử dụng
2593	CMC Quận 9	datacenter	Đang sử dụng
2594	VNPT Tân Thuận	datacenter	Đang sử dụng
2595	ODS	datacenter	Đang sử dụng
\.


--
-- Data for Name: status_catalog; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.status_catalog (code, label, tag_style, attention, sort_order) FROM stdin;
in_use	Đang vận hành	live	f	1
broken	Hỏng	repair	t	6
pending_disposal	Chờ thanh lý	warn	t	7
retired	Đã thanh lý	retired	f	8
in_stock	Lưu kho	stock	f	3
in_use_needs_replacement	Đang vận hành · cần thay	warn	t	2
not_in_use	Không vận hành	idle	f	4
maintenance	Bảo trì	stock	f	9
degraded	degraded	idle	f	99
\.


--
-- Data for Name: supplier; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.supplier (code, name) FROM stdin;
MB2194010	Công Ty TNHH Kỹ Thuật Hạ Tầng IT
MB007275	Công Ty TNHH Kỹ Thuật Hạ Tầng IT
MB2197020	CÔNG TY CỔ PHẦN TƯ VẤN VÀ ĐÀO TẠO CÔNG NGHỆ THÔNG TIN VNE
\.


--
-- Data for Name: user_session; Type: TABLE DATA; Schema: public; Owner: atlas
--

COPY public.user_session (token, user_id, created_at, expires_at) FROM stdin;
2ZBI9nZyzvPVL5pJZM61jiE0VyBxtuWcfi6JX_JR75E	2	2026-10-12 07:05:17.44628+00	2026-10-12 15:05:17.537462+00
\.


--
-- Name: app_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atlas
--

SELECT pg_catalog.setval('public.app_user_id_seq', 6, true);


--
-- Name: asset_code_seq; Type: SEQUENCE SET; Schema: public; Owner: atlas
--

SELECT pg_catalog.setval('public.asset_code_seq', 76, true);


--
-- Name: asset_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atlas
--

SELECT pg_catalog.setval('public.asset_event_id_seq', 1486, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atlas
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 51, true);


--
-- Name: export_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atlas
--

SELECT pg_catalog.setval('public.export_template_id_seq', 6, true);


--
-- Name: import_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atlas
--

SELECT pg_catalog.setval('public.import_log_id_seq', 31, true);


--
-- Name: placement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atlas
--

SELECT pg_catalog.setval('public.placement_id_seq', 1, false);


--
-- Name: rack_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atlas
--

SELECT pg_catalog.setval('public.rack_id_seq', 23, true);


--
-- Name: room_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atlas
--

SELECT pg_catalog.setval('public.room_id_seq', 14, true);


--
-- Name: site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: atlas
--

SELECT pg_catalog.setval('public.site_id_seq', 4157, true);


--
-- Name: app_user app_user_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT app_user_pkey PRIMARY KEY (id);


--
-- Name: app_user app_user_username_key; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT app_user_username_key UNIQUE (username);


--
-- Name: asset_event asset_event_asset_id_event_sequence_key; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.asset_event
    ADD CONSTRAINT asset_event_asset_id_event_sequence_key UNIQUE (asset_id, event_sequence);


--
-- Name: asset_event asset_event_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.asset_event
    ADD CONSTRAINT asset_event_pkey PRIMARY KEY (id);


--
-- Name: asset asset_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.asset
    ADD CONSTRAINT asset_pkey PRIMARY KEY (asset_id);


--
-- Name: asset_type asset_type_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.asset_type
    ADD CONSTRAINT asset_type_pkey PRIMARY KEY (code);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: backup_config backup_config_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.backup_config
    ADD CONSTRAINT backup_config_pkey PRIMARY KEY (id);


--
-- Name: cluster cluster_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.cluster
    ADD CONSTRAINT cluster_pkey PRIMARY KEY (name);


--
-- Name: export_template export_template_name_key; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.export_template
    ADD CONSTRAINT export_template_name_key UNIQUE (name);


--
-- Name: export_template export_template_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.export_template
    ADD CONSTRAINT export_template_pkey PRIMARY KEY (id);


--
-- Name: import_log import_log_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.import_log
    ADD CONSTRAINT import_log_pkey PRIMARY KEY (id);


--
-- Name: placement placement_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.placement
    ADD CONSTRAINT placement_pkey PRIMARY KEY (id);


--
-- Name: rack rack_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.rack
    ADD CONSTRAINT rack_pkey PRIMARY KEY (id);


--
-- Name: rack rack_room_id_code_key; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.rack
    ADD CONSTRAINT rack_room_id_code_key UNIQUE (room_id, code);


--
-- Name: room room_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_pkey PRIMARY KEY (id);


--
-- Name: room room_site_id_code_key; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_site_id_code_key UNIQUE (site_id, code);


--
-- Name: site site_name_key; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.site
    ADD CONSTRAINT site_name_key UNIQUE (name);


--
-- Name: site site_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.site
    ADD CONSTRAINT site_pkey PRIMARY KEY (id);


--
-- Name: status_catalog status_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.status_catalog
    ADD CONSTRAINT status_catalog_pkey PRIMARY KEY (code);


--
-- Name: supplier supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.supplier
    ADD CONSTRAINT supplier_pkey PRIMARY KEY (code);


--
-- Name: user_session user_session_pkey; Type: CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.user_session
    ADD CONSTRAINT user_session_pkey PRIMARY KEY (token);


--
-- Name: idx_asset_cluster; Type: INDEX; Schema: public; Owner: atlas
--

CREATE INDEX idx_asset_cluster ON public.asset USING btree (cluster);


--
-- Name: idx_asset_datacenter; Type: INDEX; Schema: public; Owner: atlas
--

CREATE INDEX idx_asset_datacenter ON public.asset USING btree (datacenter);


--
-- Name: idx_asset_flags; Type: INDEX; Schema: public; Owner: atlas
--

CREATE INDEX idx_asset_flags ON public.asset USING gin (review_flags);


--
-- Name: idx_asset_in_store; Type: INDEX; Schema: public; Owner: atlas
--

CREATE INDEX idx_asset_in_store ON public.asset USING btree (in_store);


--
-- Name: idx_asset_origin; Type: INDEX; Schema: public; Owner: atlas
--

CREATE INDEX idx_asset_origin ON public.asset USING btree (origin);


--
-- Name: idx_asset_status; Type: INDEX; Schema: public; Owner: atlas
--

CREATE INDEX idx_asset_status ON public.asset USING btree (usage_status);


--
-- Name: idx_audit_entity; Type: INDEX; Schema: public; Owner: atlas
--

CREATE INDEX idx_audit_entity ON public.audit_log USING btree (entity, entity_id, at DESC);


--
-- Name: idx_audit_time; Type: INDEX; Schema: public; Owner: atlas
--

CREATE INDEX idx_audit_time ON public.audit_log USING btree (at DESC);


--
-- Name: idx_event_asset; Type: INDEX; Schema: public; Owner: atlas
--

CREATE INDEX idx_event_asset ON public.asset_event USING btree (asset_id, event_sequence);


--
-- Name: idx_import_log_time; Type: INDEX; Schema: public; Owner: atlas
--

CREATE INDEX idx_import_log_time ON public.import_log USING btree (created_at DESC);


--
-- Name: idx_session_expires; Type: INDEX; Schema: public; Owner: atlas
--

CREATE INDEX idx_session_expires ON public.user_session USING btree (expires_at);


--
-- Name: asset_event asset_event_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.asset_event
    ADD CONSTRAINT asset_event_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.asset(asset_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: asset asset_parent_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.asset
    ADD CONSTRAINT asset_parent_asset_id_fkey FOREIGN KEY (parent_asset_id) REFERENCES public.asset(asset_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: asset asset_rack_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.asset
    ADD CONSTRAINT asset_rack_id_fkey FOREIGN KEY (rack_id) REFERENCES public.rack(id) ON DELETE SET NULL;


--
-- Name: asset asset_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.asset
    ADD CONSTRAINT asset_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.room(id) ON DELETE SET NULL;


--
-- Name: asset asset_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.asset
    ADD CONSTRAINT asset_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.site(id) ON DELETE SET NULL;


--
-- Name: asset asset_usage_status_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.asset
    ADD CONSTRAINT asset_usage_status_fkey FOREIGN KEY (usage_status) REFERENCES public.status_catalog(code);


--
-- Name: placement placement_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.placement
    ADD CONSTRAINT placement_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.asset(asset_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: placement placement_rack_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.placement
    ADD CONSTRAINT placement_rack_id_fkey FOREIGN KEY (rack_id) REFERENCES public.rack(id) ON DELETE CASCADE;


--
-- Name: rack rack_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.rack
    ADD CONSTRAINT rack_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.room(id) ON DELETE CASCADE;


--
-- Name: room room_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.site(id) ON DELETE CASCADE;


--
-- Name: user_session user_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: atlas
--

ALTER TABLE ONLY public.user_session
    ADD CONSTRAINT user_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.app_user(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict pDGeAw2IHj4DZeSO6WGWOPpVqKoSGSSrj5pP0N5Yt6A9werxji2yGByT8r08NCh

