// Kiểm: ở 7 màn, ô tìm / ô lọc / nút thao tác nằm trong hàng công cụ (.toolbar-row) của khung
// nội dung chứ không ở topbar; màn Kho không còn ghi chú và danh sách cuộn trong khung.
const fs = require('fs');
const { JSDOM, VirtualConsole } = require('jsdom');
const html = fs.readFileSync('index.html', 'utf8');
const data = JSON.parse(fs.readFileSync('api-data.json', 'utf8'));
const errors = [];
const vc = new VirtualConsole();
vc.on('jsdomError', e => errors.push(e.detail ? e.detail.stack : e.message));
vc.on('error', (...a) => errors.push(`console.error: ${a.join(' ')}`));
const dom = new JSDOM(html, {
  runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc,
  url: 'http://localhost:8084/',
  beforeParse(w) {
    w.fetch = u => Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve(
      u === 'api/me' ? { username: 'admin', fullName: 'T', role: 'admin' }
        : u === 'api/data' ? data : u === 'api/imports' ? { imports: [] } : { ok: true }) });
    w.confirm = () => true;
    w.MGMT_DEVICE_DATA = { meta: {}, assetRows: [], historyRows: [] };
  },
});
const w = dom.window, $ = id => w.document.getElementById(id);
const report = [];
const check = (l, ok, d = '') => report.push(`${ok ? 'PASS' : 'FAIL'}  ${l}${d ? ' — ' + d : ''}`);

// màn -> các điều khiển phải nằm trong hàng công cụ của khung nội dung
const VIEWS = {
  diagram: ['diagramExpand', 'diagramCollapse'],
  store: ['storeSearch', 'storeTypeFilter', 'storeStatusFilter', 'deleteSelectedStore'],
  types: ['typeSearch', 'newType'],
  statuses: ['statusSearch', 'newStatus'],
  exports: ['newExportTemplate'],
  admin: ['newUser'],
  assets: ['exportBtn', 'newAssetBtnFull', 'assetSearchFull', 'typeFilterFull', 'deleteSelected'],
};

setTimeout(() => {
  Object.entries(VIEWS).forEach(([view, ids]) => {
    const page = $(`${view}View`);
    const top = page.querySelector('.topbar');
    const inTop = [...top.querySelectorAll('input, select, button')].map(n => n.id || n.tagName);
    check(`${view}: topbar không còn ô lọc / nút`, inTop.length === 0, inTop.join(', '));
    const lac = ids.filter(id => !$(id) || !$(id).closest('.toolbar-row') || !page.contains($(id)));
    check(`${view}: điều khiển nằm trong hàng công cụ của khung`, lac.length === 0, lac.join(', ') || ids.join(', '));
    const lech = ids.filter(id => $(id) && $(id).closest('.toolbar-row')?.firstElementChild?.contains($(id)));
    check(`${view}: điều khiển đứng bên phải, tách khỏi tiêu đề`, lech.length === 0, lech.join(', '));
  });

  // Quy ước cũ vẫn giữ: ô tìm -> ô lọc -> nút Xóa đứng cuối nhóm
  ['assetSearchFull:deleteSelected', 'storeSearch:deleteSelectedStore'].forEach(pair => {
    const [search, del] = pair.split(':');
    const group = $(search).parentElement;
    check(`${del} đứng cuối nhóm lọc`, group.lastElementChild === $(del),
      [...group.children].map(n => n.id || n.tagName).join(' -> '));
  });

  check('màn Kho không còn ghi chú', !$('storeNote') && !$('storeView').querySelector('.tree-note'));
  check('màn Kho cao đúng cửa sổ, danh sách cuộn trong khung',
    /#storeView\.active[^{]*\{[^}]*height:\s*calc\(100vh/.test(html)
      && /#storeView \.table-panel \.table-wrap[^{]*\{[^}]*min-height:\s*0/.test(html));

  console.log(report.join('\n'));
  console.log('\nlỗi runtime:', errors.length ? errors.join('\n') : 'không có');
  process.exit(report.some(l => l.startsWith('FAIL')) || errors.length ? 1 : 0);
}, 600);
